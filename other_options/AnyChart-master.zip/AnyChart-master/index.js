module.exports = require('./dist/js/anychart-bundle.min.js');
