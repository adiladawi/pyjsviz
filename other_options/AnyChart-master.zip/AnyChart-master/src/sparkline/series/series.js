/**
 * Namespace anychart.sparklineModule.series.
 * @namespace
 * @name anychart.core.sparkline.series
 */
