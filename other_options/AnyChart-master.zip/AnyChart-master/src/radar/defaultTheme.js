goog.provide('anychart.radarModule.defaultTheme');


goog.mixin(goog.global['anychart']['themes']['defaultTheme'], {
  // merge with chart
  'radar': {
    'defaultSeriesType': 'line',
    'defaultSeriesSettings': {
      'base': {
        'clip': false
      },
      'area': {},
      'line': {},
      'marker': {}
    },
    'xAxis': {
      'scale': 0,
      'zIndex': 25,
      'labels': {
        'zIndex': 25
      },
      'minorLabels': {
        'zIndex': 25
      },
      'ticks': {
        'zIndex': 25
      },
      'minorTicks': {
        'zIndex': 25
      }
    },
    'yAxis': {
      'scale': 1
    },
    'startAngle': 0,
    'innerRadius': 0,
    'xGrids': [{}],
    'yGrids': [{}],
    'minorGrids': [],
    'scales': [
      {
        'type': 'ordinal'
      },
      {
        'type': 'linear'
      }
    ],
    'xScale': 0,
    'yScale': 1,
    'a11y': {
      'titleFormat': anychart.core.defaultTheme.cartesianBaseA11yTitleFormatter
    }
  }
});
