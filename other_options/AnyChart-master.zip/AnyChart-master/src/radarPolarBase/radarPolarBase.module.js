/**
 * @fileoverview anychart.radarModule.entry namespace file.
 * @suppress {extraRequire}
 */

goog.provide('anychart.radarPolarBaseModule.entry');
goog.require('anychart.radarPolarBaseModule.Chart');
