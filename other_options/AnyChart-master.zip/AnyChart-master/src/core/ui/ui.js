/**
 * Namespace anychart.core.ui.
 * @namespace
 * @name anychart.core.ui
 */
