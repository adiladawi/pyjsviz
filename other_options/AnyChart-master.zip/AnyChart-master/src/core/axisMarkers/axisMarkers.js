/**
 * Namespace anychart.core.axisMarkers.
 * @namespace
 * @name anychart.core.axisMarkers
 */
