/**
 * Namespace anychart.core.utils.
 * @namespace
 * @name anychart.core.utils
 */
