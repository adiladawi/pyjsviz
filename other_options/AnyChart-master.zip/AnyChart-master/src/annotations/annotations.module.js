goog.provide('anychart.annotationsModule.entry');

goog.require('anychart.annotationsModule.ChartController');
goog.require('anychart.annotationsModule.PlotController');
