goog.provide('anychart.colorScalesModule');
goog.provide('anychart.colorScalesModule.entry');

goog.require('anychart.colorScalesModule.Linear');
goog.require('anychart.colorScalesModule.Ordinal');
goog.require('anychart.colorScalesModule.ui.ColorRange');
