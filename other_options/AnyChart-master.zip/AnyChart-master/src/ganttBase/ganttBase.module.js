/**
 * @fileoverview anychart.ganttModule.entry namespace file.
 * @suppress {extraRequire}
 */

goog.provide('anychart.ganttBaseModule.entry');

goog.require('anychart.ganttBaseModule.Overlay');
goog.require('anychart.ganttBaseModule.TimeLineHeader');
