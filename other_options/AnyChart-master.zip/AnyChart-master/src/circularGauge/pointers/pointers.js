/**
 * Namespace anychart.circularGaugeModule.pointers.
 * @namespace
 * @name anychart.core.gauge.pointers
 */
