(function() { const icons = { "linear/basic/flag": "M10.8 64V0h3v4.9h41.3l-6.6 13.3 6.6 13.3H13.8V64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();