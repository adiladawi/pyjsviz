(function() { const icons = { "linear/basic/download": "M33.5 54V25.6h-3V54l-5.7-5.7-2 2.3 8.3 8.5h1.8l8.4-8.5-2.1-2.2-5.7 5.6zM0 4.9v38.4h24.6v-2.9H3V7.9h58v32.5H39.4v2.9H64V4.9H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();