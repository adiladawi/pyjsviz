(function() { const icons = { "linear/basic/magnifier-minus": "M11.7 22.4h18.5v-2.9H11.7v2.9zm31.7 13.1l-2.9 2.9-3.7-3.7C40.2 30.9 42 26 42 21 42 9.4 32.6 0 21 0S0 9.4 0 21s9.4 21 21 21c5 0 9.9-1.9 13.7-5.2l3.7 3.7-2.9 2.9L56.1 64l7.9-7.9-20.6-20.6zM21 39C11 39 3 30.8 3 20.9c0-9.9 8.1-18 18-18S39 11.1 39 21s-8 18-18 18z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();