(function() { const icons = { "linear/basic/todo": "M8.9 64V6.9h13.4l.7-3h3.6V0h10.8v3.9H41l.7 3h13.4V64H8.9zM40 11.8l-1.2-4.9h-4.3V3h-4.9v3.9h-4.3L24 11.8h16z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();