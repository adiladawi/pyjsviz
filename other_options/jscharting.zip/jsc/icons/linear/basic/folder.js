(function() { const icons = { "linear/basic/folder": "M22.4 9H0v46h64V17H30.4l-8-8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();