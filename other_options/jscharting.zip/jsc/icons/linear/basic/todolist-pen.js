(function() { const icons = { "linear/basic/todolist-pen": "M53.2 2v3.9h-3.9v11.8h3V8.9h1V53l5.4 10.8L64 53V2H53.2zm-21 1.9h-3.6V0H17.7v3.9h-3.6l-.7 3H0V64h46.3V6.9H32.9l-.7-3zM12.8 55.1H7.9v-3h4.9v3zm0-9.8H7.9v-3h4.9v3zm0-9.9H7.9v-3h4.9v3zm0-9.8H7.9v-3h4.9v3zm3.6-18.7h4.3V3h4.9v3.9h4.3l1.2 4.9H15.2l1.2-4.9zm22 48.2H15.8v-3h22.6v3zm0-9.8H15.8v-3h22.6v3zm0-9.9H15.8v-3h22.6v3zm0-9.8H15.8v-3h22.6v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();