(function() { const icons = { "linear/basic/sheet-pencil": "M53.2 0v54l5.4 10.8L64 54V0H53.2zM61 9.9h-4.9V3H61v6.9zM30.6 2H0v60h43.3V14.7L30.6 2zM7.9 14.8v-2.9h12.8v2.9H7.9zm27.5 30.5v2.9H7.9v-2.9h27.5zm0-7.9v2.9H7.9v-2.9h27.5zm0-7.8v2.9H7.9v-2.9h27.5zm0-7.9v2.9H7.9v-2.9h27.5zm-3.9-7.9V7l6.8 6.8h-6.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();