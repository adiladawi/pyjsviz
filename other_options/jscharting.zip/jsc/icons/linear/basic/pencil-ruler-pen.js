(function() { const icons = { "linear/basic/pencil-ruler-pen": "M7.2 10.7V64h10.7V10.7L12.6 0 7.2 10.7zM15 61.1h-4.9v-6.8H15v6.8zM46.1 2.8v3.9h-3.9v11.6h2.9V9.6h1v43.6l5.3 10.7 5.4-10.7V2.8zM30.5 53.3v-2.9h8.8v-6.8h-4.9v-2.9h4.9v-6.8h-8.8V31h8.8v-6.8h-4.9v-3h4.9v-6.8h-8.8v-2.9h8.8V.8H20.8V64h18.5V53.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();