(function() { const icons = { "linear/basic/archive": "M3.9 64V39.4h.2l6-39.4H54l5.9 39.4h.2V64H3.9zm18.7-24.6v1.5c0 5.2 4.2 9.4 9.4 9.4s9.4-4.2 9.4-9.4v-1.5h15.5L51.4 3H12.6L7.1 39.4h15.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();