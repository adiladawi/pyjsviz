(function() { const icons = { "linear/basic/clockwise": "M33.5 55.5h-3v5h3v-5zm8.9-15.2l-8.9-8.9V11.5h-3v21.1l9.8 9.8 2.1-2.1zM33.5 3.5h-3v5h3v-5zm22 27v3h5v-3h-5zm-52 3h5v-3h-5v3zM32 0h-.5v3h.5c16 0 29 13 29 29S48 61 32 61 3 48 3 32c0-6.1 1.8-11.9 5.2-16.8l3.6-3.6v8h3V8.1l-1.3-1.3H2v3h7.4L6 13.2l-.1.2C2.1 18.9 0 25.3 0 32c0 17.6 14.4 32 32 32s32-14.4 32-32S49.6 0 32 0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();