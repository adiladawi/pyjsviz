(function() { const icons = { "linear/basic/cup": "M19.7 64v-3h10.8V36.4c-9.4-.4-15.8-4.1-15.8-9.3v-9.4C6 16.7 5.9 7.5 5.9 7.4V5.9h8.9V0h34.5v5.9h8.9v1.5c0 .1-.1 9.3-8.9 10.3v9.4c0 5.2-6.3 9-15.8 9.3V61h10.8v3H19.7zm29.5-49.3c4-.6 5.3-3.7 5.7-5.8h-5.7v5.8zM9 8.9c.4 2.1 1.7 5.2 5.7 5.8V8.9H9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();