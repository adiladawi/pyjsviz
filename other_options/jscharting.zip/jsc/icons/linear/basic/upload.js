(function() { const icons = { "linear/basic/upload": "M32.9 24.6h-1.8l-8.4 8.5 2.1 2.2 5.7-5.7v28.5h3V29.6l5.7 5.8 2.1-2.3-8.4-8.5zM0 4.9v38.4h24.6v-2.9H3V7.9h58v32.5H39.4v2.9H64V4.9H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();