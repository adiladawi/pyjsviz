(function() { const icons = { "linear/basic/keyboard": "M8.9 20.6v-4.9h13.8V5.9h-9.8v-2h-3v4.9h9.8v3.9H5.9v7.9H0v32.5h64V20.6H8.9zm42.3 6.9h4.9v3h-4.9v-3zm-5.9 0h4.9v3h-4.9v-3zm-5.9 0h4.9v3h-4.9v-3zm-5.9 0h4.9v3h-4.9v-3zm2.9 7.9v3h-4.9v-3h4.9zm-8.8-7.9h4.9v3h-4.9v-3zm2.9 7.9v3h-4.9v-3h4.9zm-8.8-7.9h4.9v3h-4.9v-3zm2.9 7.9v3h-4.9v-3h4.9zm-8.8-7.9h4.9v3h-4.9v-3zm2.9 7.9v3h-4.9v-3h4.9zm-8.9-7.9h4.9v3H9.8v-3zm3 7.9v3H7.9v-3h4.9zm-8.9-7.9h4.9v3H3.9v-3zm5 18.7h-5v-3h4.9v3zm5.9 0h-5v-3h4.9v3zm27.5 0H15.8v-3h26.6v3zm0-7.9h-4.9v-3h4.9v3zm5.9 7.9h-4.9v-3h4.9v3zm0-7.9h-4.9v-3h4.9v3zm6 7.9h-4.9v-3h4.9v3zm0-7.9h-4.9v-3h4.9v3zm5.9 7.9h-4.9v-3h4.9v3zm0-7.9h-4.9v-3h4.9v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();