(function() { const icons = { "linear/basic/calculator": "M0 0v64h64V0H0zm27.4 53.3l-2.1 2.1-7.3-7.3-7.3 7.3-2.1-2.1 7.3-7.3-7.3-7.3 2.1-2.1 7.3 7.3 7.3-7.3 2.1 2.1-7.3 7.3 7.3 7.3zm1.1-33.8h-9v9h-3v-9h-9v-3h9v-9h3v9h9v3zm28 31h-21v-3h21v3zm0-6h-21v-3h21v3zm0-25h-21v-3h21v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();