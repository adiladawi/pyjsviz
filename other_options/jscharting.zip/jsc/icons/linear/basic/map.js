(function() { const icons = { "linear/basic/map": "M22.4 4.8l19.2 7.7v46.8l-19.2-7.7V4.8zM0 12.5l20.3-7.7v46.8L0 59.3V12.5zm64 39l-20.3 7.7V12.5L64 4.7v46.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();