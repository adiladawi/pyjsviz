(function() { const icons = { "linear/basic/calendar": "M18.5 43.5h-7v7h7v-7zm17 0h-7v7h7v-7zm-17-18h-7v7h7v-7zm17 0h-7v7h7v-7zm17 0h-7v7h7v-7zm0 18h-7v7h7v-7zm.7-34.6v-4h-8.9v3.9H19.7V4.9h-8.9v3.9H0V59h64V8.9H53.2zM21.5 53.5h-13v-13h13v13zm0-18h-13v-13h13v13zm17 18h-13v-13h13v13zm0-18h-13v-13h13v13zm17 18h-13v-13h13v13zm0-18h-13v-13h13v13zM61 16.7H3v-4.9h7.9v3.9h8.9v-3.9h24.6v3.9h8.9v-3.9H61v4.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();