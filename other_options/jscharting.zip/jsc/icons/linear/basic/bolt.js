(function() { const icons = { "linear/basic/bolt": "M37.8 0L14.4 36.5l.9 1.6h12.9l-6.8 25.1 1.8.9 26.4-36.5-.8-1.6h-13L39.7.8c-.1-.1-1.9-.8-1.9-.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();