(function() { const icons = { "linear/basic/notebook-pen": "M8.9 54.2H0v3h8.9v-3zm0-7.9H0v3h8.9v-3zm0-31.5H0v3h8.9v-3zm0 7.9H0v3h8.9v-3zM53.2 2v3.9h-3.9v11.8h3V8.9h1V53l5.4 10.8L64 53V2H53.2zM8.9 38.4H0v3h8.9v-3zm0-7.9H0v3h8.9v-3zM3 4.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3V62h42.3V2H3v2.9zm32.4 0h6.9v54.2h-6.9V4.9zm-26.5 2H0v3h8.9v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();