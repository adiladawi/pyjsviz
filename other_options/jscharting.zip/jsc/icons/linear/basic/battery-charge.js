(function() { const icons = { "linear/basic/battery-charge": "M60.1 25.6v-5.9H0v26.6h60.1v-5.9H64V25.6h-3.9zm-3 17.8H3V22.7h54.1v20.7zm3.9-6h-1v-8.9h1v8.9zM56 24H4v18h52V24zM27.5 38.3v-6l-5.4 2.3-1.2-2.8 9.6-4.1v6l5.4-2.3 1.2 2.8-9.6 4.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();