(function() { const icons = { "linear/basic/picture-multiple": "M0 57.1h54.2V14.8H0v42.3zm3-39.4h48.2v32.8L39 40l-9.6 5.8-14-16L3 42.2V17.7zm36.9 17.7c3.5 0 6.4-2.9 6.4-6.4s-2.9-6.4-6.4-6.4-6.4 2.9-6.4 6.4 2.9 6.4 6.4 6.4zm0-9.8c1.9 0 3.4 1.5 3.4 3.4s-1.5 3.4-3.4 3.4-3.4-1.5-3.4-3.4 1.5-3.4 3.4-3.4zM8.9 6.9v5.9h47.3v36.4H64V6.9H8.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();