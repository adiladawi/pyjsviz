(function() { const icons = { "linear/basic/book": "M5.9 0v64h48.2V0H5.9zm7.9 61h-5V3h4.9v58zm34.7-38.5h-29v-3h29v3zm0-6h-29v-3h29v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();