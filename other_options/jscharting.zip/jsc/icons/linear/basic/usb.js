(function() { const icons = { "linear/basic/usb": "M32 9.7l-3.9 3.8L14.6 0 0 14.6l13.6 13.5L9.7 32l32 32L64 41.7l-32-32zM15.6 26.1L4.1 14.6 14.6 4.1l11.5 11.5-10.5 10.5zM6.5 14.3l9.4 9.4 2-2-9.4-9.4-2 2zm5.8-5.8l9.4 9.4 2-2-9.4-9.4-2 2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();