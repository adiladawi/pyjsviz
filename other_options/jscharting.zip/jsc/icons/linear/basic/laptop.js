(function() { const icons = { "linear/basic/laptop": "M34.5 14.5h-5v3h5v-3zM0 45v8h64v-8H0zm57.5-34.5h-51v33h51v-33zm-3 30h-45v-27h45v27z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();