(function() { const icons = { "linear/basic/mail-open-text": "M45.2 7.8h-9.8v3h9.8v-3zm.1 7.9H18.7v3h26.6v-3zm0 7.9H18.7v3h26.6v-3zm8.8-2.6V0H9.8v21L0 25.1V64h63.9V25.1L54.1 21zM9.8 29.6l-5.2-3.2 5.2-2.2v5.4zm41.4 1.9L32 43.5l-19.2-12V3h38.4v28.5zm3-1.9v-5.4l5.2 2.2-5.2 3.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();