(function() { const icons = { "linear/basic/message-txt": "M0 4v44h17v13.2L32.4 48H64V4H0zm54.5 33.5h-45v-3h45v3zm0-10h-45v-3h45v3zm0-10h-45v-3h45v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();