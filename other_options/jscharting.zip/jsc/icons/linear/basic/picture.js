(function() { const icons = { "linear/basic/picture": "M0 9.8v44.3h64V9.8H0zm61 35.7L41.6 28.8l-5.8 7.8L24.2 25 3 43.5V12.8h58v32.7zM50.7 28.6c3.5 0 6.4-2.9 6.4-6.4s-2.9-6.4-6.4-6.4-6.4 2.9-6.4 6.4 2.9 6.4 6.4 6.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();