(function() { const icons = { "linear/basic/battery-half": "M60.1 25.6v-5.9H0v26.6h60.1v-5.9H64V25.6h-3.9zm-3 17.8H3V22.7h54.1v20.7zm3.9-6h-1v-8.9h1v8.9zM29.8 24H4v18h30.3l-4.5-18z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();