(function() { const icons = { "linear/basic/sheet-txt": "M22.5 0L7.9 14.7V64h48.2V0H22.5zm-.8 5v8.7H13L21.7 5zm24.6 50.1H17.7v-3h28.6v3zm0-9.8H17.7v-3h28.6v3zm0-9.9H17.7v-3h28.6v3zm0-9.8H17.7v-3h28.6v3zm0-9.8H31.5v-3h14.8v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();