(function() { const icons = { "linear/basic/anticlockwise": "M30.5 8.8h3V3.9h-3v4.9zm0 51.3h3v-4.9h-3v4.9zm11.8-19.9l-8.8-8.8V11.8h-3v20.8l9.7 9.7 2.1-2.1zM8.8 33.5v-3H3.9v3h4.9zm46.3-3v3H60v-3h-4.9zM58 13.4l-3.5-3.5H62v-3H50.5l-1.3 1.3v11.5h3v-8l3.5 3.5C59.2 20.1 61 25.9 61 32c0 16-13 29-29 29S3 48 3 32 16 3 32 3h.5V0H32C14.4 0 0 14.4 0 32s14.4 32 32 32 32-14.4 32-32c0-6.7-2.1-13.1-6-18.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();