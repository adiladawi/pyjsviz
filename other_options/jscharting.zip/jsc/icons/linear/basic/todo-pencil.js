(function() { const icons = { "linear/basic/todo-pencil": "M53.2 54V0H64v54l-5.4 10.8L53.2 54zM61 9.9V3h-4.9v6.9H61zM0 64V6.9h13.4l.7-3h3.6V0h10.8v3.9h3.6l.7 3h13.4V64H0zm31.1-52.2l-1.2-4.9h-4.3V3h-4.9v3.9h-4.3l-1.2 4.9h15.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();