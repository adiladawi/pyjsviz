(function() { const icons = { "linear/basic/webpage-multiple": "M9.8 5.9v6.9h47.3v38.4H64V5.9H9.8zM0 58.1h56.1V13.8H0v44.3zm21.7-40.4h4.9v3h-4.9v-3zm-7.9 0h4.9v3h-4.9v-3zm-7.9 0h4.9v3H5.9v-3zM3 24.6h50.2v30.5H3V24.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();