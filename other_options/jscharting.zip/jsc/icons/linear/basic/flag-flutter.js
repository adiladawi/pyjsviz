(function() { const icons = { "linear/basic/flag-flutter": "M5.9 64V0h3v4.9h24.6v4.9H59l-6.6 13.3L59 36.4H24.6v-4.9H8.9V64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();