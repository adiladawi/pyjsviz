(function() { const icons = { "linear/basic/message-multiple": "M0 50h13v11.7L26.4 50H56V10H0v40zM8 2v6h50v34h6V2H8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();