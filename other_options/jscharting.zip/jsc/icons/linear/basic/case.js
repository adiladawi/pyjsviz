(function() { const icons = { "linear/basic/case": "M42.2 16.7C41.7 14 39.7 8.8 32 8.8s-9.7 5.2-10.2 7.9H0v11.8h64V16.7H42.2zm-17.4 0c.5-2.1 2.1-4.9 7.2-4.9 5 0 6.6 2.9 7.2 4.9H24.8zm13.7 20.8h-13v-6H0v23.6h64V31.5H38.5v6zm-10-6v3h7v-3h-7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();