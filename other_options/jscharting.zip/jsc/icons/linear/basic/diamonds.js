(function() { const icons = { "linear/basic/diamonds": "M33 64.7L57.2 32 33-.7 8.8 32 33 64.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();