(function() { const icons = { "linear/basic/signs": "M23.6 64v-3h6.9V41.2H8.7L0 33.8l8.7-7.4h21.8v-1h-9.9V10.5h9.9v-4h3v4h21.8l8.7 7.4-8.7 7.4H33.5v1h9.9v14.9h-9.9V61h6.9v3H23.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();