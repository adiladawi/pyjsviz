(function() { const icons = { "linear/basic/geolocalize": "M32 0C19.9 0 10 10.2 10 22.7c0 15.7 20.3 39.9 21.2 40.9l.8.9.8-.9c.9-1 21.3-25.2 21.3-40.9C53.9 10.2 44.1 0 32 0zm0 29c-3.9 0-7-3.1-7-7s3.1-7 7-7 7 3.1 7 7-3.1 7-7 7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();