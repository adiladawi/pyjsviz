(function() { const icons = { "linear/basic/trashcan-full": "M63.4 48.7l-4.8-16.6-5.9 2L49 21.2l-1.7.5v-9.8h-2.5L39.9 0H26.4l-4.1 5.1-9.1-.1-2 6.9H8.9V64h38.4V25.9l11 37.6 2.8-.8-3.5-12 5.8-2zM15.5 7.9L22 8l1.2 3.8h-8.8l1.1-3.9zm8.2 48.2h-3V21.7h3v34.4zm11.8 0h-3V21.7h3v34.4zm-9.2-44.3l-1.6-5L27.8 3H38l3.7 8.9H26.3zm27.3 25.1l3-1 3.1 10.9-3 1-3.1-10.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();