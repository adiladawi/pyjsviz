(function() { const icons = { "linear/basic/paperplane": "M61.6.3L0 29.1v2.4l20.3 10.1zM22.4 43.7L32.5 64h2.4L63.7 2.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();