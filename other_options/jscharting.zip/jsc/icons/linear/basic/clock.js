(function() { const icons = { "linear/basic/clock": "M54.6 9.4C48.6 3.3 40.5 0 32 0S15.4 3.3 9.4 9.4C3.3 15.4 0 23.5 0 32s3.3 16.6 9.4 22.6c6 6 14.1 9.4 22.6 9.4s16.6-3.3 22.6-9.4c6-6 9.4-14.1 9.4-22.6s-3.3-16.6-9.4-22.6zM8.5 33.5h-5v-3h5v3zm22-30h3v5h-3v-5zm3 57h-3v-5h3v5zm6.8-18.1l-9.8-9.8V11.5h3v19.9l8.9 8.9-2.1 2.1zm15.2-8.9v-3h5v3h-5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();