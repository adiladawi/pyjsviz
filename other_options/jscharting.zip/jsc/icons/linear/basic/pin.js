(function() { const icons = { "linear/basic/pin": "M30.5 64V37.4h-17l1.4-8.4 8.8-3.9L25.5 10l-4.8-3.9V0h22.6v6.1L38.5 10l1.8 15.1 8.8 3.9 1.4 8.4h-17V64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();