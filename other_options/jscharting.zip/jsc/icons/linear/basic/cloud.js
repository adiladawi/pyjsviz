(function() { const icons = { "linear/basic/cloud": "M56 33c-.5-11.1-10.1-20-21.9-20-10.4 0-19.6 6.8-21.9 16h-.9C5.1 29 0 33.9 0 40c0 6.2 4.8 11 11 11h44c5 0 9-4 9-9 0-4.7-3.5-8.5-8-9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();