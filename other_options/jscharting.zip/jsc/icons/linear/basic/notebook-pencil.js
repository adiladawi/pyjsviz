(function() { const icons = { "linear/basic/notebook-pencil": "M8.9 54.2H0v3h8.9v-3zm0-7.9H0v3h8.9v-3zm0-31.5H0v3h8.9v-3zM53.2 0v54l5.4 10.8L64 54V0H53.2zM61 9.9h-4.9V3H61v6.9zM8.9 22.7H0v3h8.9v-3zm0 15.7H0v3h8.9v-3zm0-7.9H0v3h8.9v-3zM3 4.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3v.9h7.9v7H3V62h42.3V2H3v2.9zm32.4 0h6.9v54.2h-6.9V4.9zm-26.5 2H0v3h8.9v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();