(function() { const icons = { "linear/basic/postcard": "M55.5 20.5h-5v7h5v-7zM0 12v43h64V12H0zm5.5 13.5h25v3h-25v-3zm27 9h-27v-3h27v3zm2-12h-29v-3h29v3zm6 27h-3v-32h3v32zm18-19h-11v-13h11v13z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();