(function() { const icons = { "linear/basic/home": "M-.4 34H10v30h14V48h14v16h14V34h12.4L32 1.6-.4 34z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();