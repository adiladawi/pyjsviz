(function() { const icons = { "linear/basic/spread-text-bookmark": "M50 25.4V8.7l-6 .8v15.9l3-1.5 3 1.5zM2 53.1l29 3.7v-46L2 7.1v46zM7.1 15l19 2-.2 2-19-2 .2-2zm0 10l19 2-.2 2-19-2 .2-2zm0 10l19 2-.2 2-19-2 .2-2zm0 10l19 2-.2 2-19-2 .2-2zM52 8.4v20.2l-5-2.5-5 2.5V9.7l-9 1.2v46l29-3.7v-46L52 8.4zM38.1 49l-.2-2 19-2 .2 2-19 2zm0-10l-.2-2 19-2 .2 2-19 2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();