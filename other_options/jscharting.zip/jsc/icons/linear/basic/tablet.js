(function() { const icons = { "linear/basic/tablet": "M32 56.1c-.3 0-.5.2-.5.5s.2.5.5.5.5-.2.5-.5-.2-.5-.5-.5zM9.8 0v64h44.3V0H9.8zm17.8 3.9h8.9v3h-8.9v-3zM32 60.1c-1.9 0-3.4-1.5-3.4-3.4s1.5-3.4 3.4-3.4 3.4 1.5 3.4 3.4c0 1.8-1.5 3.4-3.4 3.4zm19.2-10.9H12.8V10.8h38.4v38.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();