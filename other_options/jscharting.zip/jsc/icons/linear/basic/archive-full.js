(function() { const icons = { "linear/basic/archive-full": "M59.9 39.4L54 0H10.1l-6 39.4h-.2V64h56.2V39.4h-.2zm-18.5 0v1.5c0 5.2-4.2 9.4-9.4 9.4s-9.4-4.2-9.4-9.4v-1.5H7.1L12.6 3h38.8l5.5 36.4H41.4zm8.8-19.8H13.8v3h36.4v-3zm-1.9-9.8H15.8v3h32.5v-3zM11.8 32.5h40.4v-3H11.8v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();