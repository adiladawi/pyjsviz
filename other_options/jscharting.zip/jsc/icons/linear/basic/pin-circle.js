(function() { const icons = { "linear/basic/pin-circle": "M32 0c-9 0-16.2 7.3-16.2 16.2 0 8.4 6.5 15.4 14.8 16.2V64h3V32.4c8.3-.8 14.8-7.8 14.8-16.2C48.2 7.3 41 0 32 0zm.5 8H32c-4.6 0-8.3 3.7-8.3 8.3v.5h-3v-.5C20.8 10 25.8 5 32 5h.5v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();