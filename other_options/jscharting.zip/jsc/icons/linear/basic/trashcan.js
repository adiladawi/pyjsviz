(function() { const icons = { "linear/basic/trashcan": "M40.4 7.9V0H23.6v7.9H9.8v3h3V64h38.4V10.8h3v-3H40.4zM26.6 3h10.8v4.9H26.6V3zm1 51.2h-3V19.7h3v34.5zm11.8 0h-3V19.7h3v34.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();