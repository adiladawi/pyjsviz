(function() { const icons = { "linear/basic/hammer": "M35.7 41.7l2.9-2.9-16.3-16.3-9.7 9.7L0 19.4 17.5 1.9l1 1C20.1 4.6 22 5.4 24 5.4c2.9 0 5.2-1.6 5.2-1.6l1-.7L36 8.8 24.4 20.4l16.3 16.3 2.9-2.9L64 54.2 56.2 62 35.7 41.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();