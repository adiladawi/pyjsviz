(function() { const icons = { "linear/basic/heart": "M48 4c-7.4 0-13.6 4.1-16 9.9C29.6 8.1 23.4 4 16 4 6 4 0 12.6 0 21c0 8.6 5.3 17.8 15.8 27.2 7.7 7 15.6 11.6 15.7 11.6l.5.3.5-.3c.1 0 7.9-4.6 15.7-11.6C58.7 38.8 64 29.6 64 21c0-8.4-6-17-16-17z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();