(function() { const icons = { "linear/basic/todo-pen": "M0 64V6.9h13.4l.7-3h3.6V0h10.8v3.9h3.6l.7 3h13.4V64H0zm31.1-52.2l-1.2-4.9h-4.3V3h-4.9v3.9h-4.3l-1.2 4.9h15.9zM53.2 53V8.9h-1v8.9h-3V5.9h3.9V2H64v51l-5.4 10.8L53.2 53z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();