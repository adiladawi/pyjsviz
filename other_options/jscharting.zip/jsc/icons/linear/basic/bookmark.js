(function() { const icons = { "linear/basic/bookmark": "M17 64.4l15-15 15 15V0H17v64.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();