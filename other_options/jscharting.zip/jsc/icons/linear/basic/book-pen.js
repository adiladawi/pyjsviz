(function() { const icons = { "linear/basic/book-pen": "M53.2 53V8.9h-1v8.8h-3V5.9h4V2H64v51l-5.4 10.9zM0 0v64h48.2V0H0zm7.9 61H3V3h4.9v58zm34.6-38.5h-29v-3h29v3zm0-6h-29v-3h29v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();