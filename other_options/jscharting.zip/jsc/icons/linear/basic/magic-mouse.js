(function() { const icons = { "linear/basic/magic-mouse": "M32 0c-9.4 0-17 7.6-17 17v30c0 9.4 7.6 17 17 17s17-7.6 17-17V17c0-9.4-7.6-17-17-17zm1.5 18.5h-3v-9h3v9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();