(function() { const icons = { "linear/basic/printer": "M49.2 18.7V0H14.8v18.7H0v34.5h14.8V64h34.5V53.2H64V18.7H49.2zm-38.4 9.9H5.9v-3h4.9v3zm5.9 0h-4.9v-3h4.9v3zM46.3 61H17.7V40.4h28.6V61zm0-42.3H17.7V3h28.6v15.7zm-3.9 26.5H21.7v3h20.7v-3zm0 7.9H21.7v3h20.7v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();