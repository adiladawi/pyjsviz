(function() { const icons = { "linear/basic/display": "M21.7 64.1v-3h8.9v-8.9H0V8.9h64v43.3H33.5v8.9h8.9v3H21.7zM61 41.4V11.9H3v29.5h58z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();