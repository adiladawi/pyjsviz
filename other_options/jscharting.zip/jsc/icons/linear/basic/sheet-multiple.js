(function() { const icons = { "linear/basic/sheet-multiple": "M6.9 20.6V64h41.4V7.9H19.6L6.9 20.6zm11.8-.9h-6.8l6.8-6.8v6.8zM28.4 0l-5.8 5.9h27.6v50.2h6.9V0H28.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();