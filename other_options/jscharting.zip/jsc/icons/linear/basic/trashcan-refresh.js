(function() { const icons = { "linear/basic/trashcan-refresh": "M40.4 7.9V0H23.6v7.9H9.8v3h3V64h38.4V10.8h3v-3H40.4zM26.6 3h10.8v4.9H26.6V3zm9.8 42.6L33 50l-2.5-1.7 1.5-2h-1c-5.4 0-9.4-5.5-9.4-10.3v-.5h3v.5c0 3.4 2.8 7.4 6.4 7.4h1l-1.4-2 2.4-1.8 3.4 4.4v1.6zm5.9-9.2h-3v-.5c0-3.4-2.8-7.4-6.4-7.4h-1l1.5 2-2.4 1.8-3.4-4.4v-1.5L31 22l2.5 1.7-1.5 2h1c5.4 0 9.4 5.5 9.4 10.3v.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();