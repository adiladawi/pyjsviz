(function() { const icons = { "linear/basic/trashcan-remove": "M40.4 7.9V0H23.6v7.9H9.8v3h3V64h38.4V10.8h3v-3H40.4zM26.6 3h10.8v4.9H26.6V3zm13.7 39.1l-2.1 2.1L32 38l-6.2 6.2-2.1-2.1 6.2-6.2-6.2-6.2 2.1-2.1 6.2 6.2 6.2-6.2 2.1 2.1-6.2 6.2 6.2 6.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();