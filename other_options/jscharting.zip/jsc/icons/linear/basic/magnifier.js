(function() { const icons = { "linear/basic/magnifier": "M35.5 43.4l2.9-2.9-3.7-3.7C30.9 40.1 26 42 21 42 9.4 42 0 32.6 0 21S9.4 0 21 0s21 9.4 21 21c0 5-1.8 9.9-5.2 13.7l3.7 3.7 2.9-2.9L64 56.1 56.1 64 35.5 43.4zM21 2.9c-9.9 0-18 8.1-18 18S11 39 21 39s18-8.1 18-18S30.9 2.9 21 2.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();