(function() { const icons = { "linear/basic/todo-txt": "M41.8 6.9l-.7-3h-3.6V0H26.6v3.9H23l-.7 3H8.9V64h46.3V6.9H41.8zM21.7 55.1h-4.9v-3h4.9v3zm0-9.8h-4.9v-3h4.9v3zm0-9.9h-4.9v-3h4.9v3zm0-9.8h-4.9v-3h4.9v3zm3.6-18.7h4.3V3h4.9v3.9h4.3l1.2 4.9H24l1.3-4.9zm22 48.2H24.6v-3h22.6v3zm0-9.8H24.6v-3h22.6v3zm0-9.9H24.6v-3h22.6v3zm0-9.8H24.6v-3h22.6v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();