(function() { const icons = { "linear/basic/folder-multiple": "M20 14H0v41h57V21H27.1L20 14zm14.1-1L27 6H7v6h13.9l.5.6L28 19h31v28h5V13H34.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();