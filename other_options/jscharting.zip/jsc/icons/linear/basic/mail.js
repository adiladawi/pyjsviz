(function() { const icons = { "linear/basic/mail": "M32 34.7L0 14v37.2h64V14L32 34.7zm30-22.9H2l30 19.4 30-19.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();