(function() { const icons = { "linear/basic/postcard-multiple": "M9 10v7h48v29h7V10H9zm34.5 21.5h4v-5h-4v5zM0 55h55V19H0v36zm40.5-31.5h10v11h-10v-11zm-9 0h3v27h-3v-27zm-27 2h25v3h-25v-3zm0 5h22v3h-22v-3zm0 5h23v3h-23v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();