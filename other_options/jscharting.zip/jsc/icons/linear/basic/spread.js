(function() { const icons = { "linear/basic/spread": "M0 5.5l30.9 4v49L0 54.5v-49zm64 49l-30.9 4v-49l30.9-4v49z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();