(function() { const icons = { "linear/basic/message": "M0 48h17v13.2L32.4 48H64V4H0v44z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();