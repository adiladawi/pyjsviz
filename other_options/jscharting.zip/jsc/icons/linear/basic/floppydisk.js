(function() { const icons = { "linear/basic/floppydisk": "M51.3 0H0v64h64V12.7L51.3 0zM16.7 3h30.6v15.8H16.7V3zm38.4 58H8.9V32.5h46.2V61zM36.4 17.7h7.9V3.9h-7.9v13.8zm13.8 35.4H13.8v3h36.4v-3zm0-7.9H13.8v3h36.4v-3zm0-7.8H13.8v3h36.4v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();