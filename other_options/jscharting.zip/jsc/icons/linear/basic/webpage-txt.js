(function() { const icons = { "linear/basic/webpage-txt": "M58.1 23.6H5.9v3h52.2v-3zm0 15.7H5.9v3h52.2v-3zm0-7.8H5.9v3h52.2v-3zM0 5.9v52.2h64V5.9H0zm21.7 3.9h4.9v3h-4.9v-3zm-7.9 0h4.9v3h-4.9v-3zm-7.9 0h4.9v3H5.9v-3zM61 55.1H3V16.7h58v38.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();