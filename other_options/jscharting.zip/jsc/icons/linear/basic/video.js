(function() { const icons = { "linear/basic/video": "M23.7 37.4H8.9v6.9h14.8v-6.9zm23.6-9.9v-8.7h-6.8l-7.9-7.9H5.9v3h25.5l4.9 4.9H0v34.5h47.3v-8.7L64 54.3V17.6l-16.7 9.9zm-33.5-.9h4.9v3h-4.9v-3zm-7.9 0h4.9v3H5.9v-3zm20.7 20.7H5.9V34.5h20.7v12.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();