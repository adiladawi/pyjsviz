(function() { const icons = { "linear/basic/sheet-pen": "M0 2v60h43.3V14.7L30.6 2H0zm7.9 9.8h12.8v3H7.9v-3zm27.5 36.5H7.9v-3h27.6v3zm0-7.9H7.9v-3h27.6v3zm0-7.9H7.9v-3h27.6v3zm0-7.9H7.9v-3h27.6v3zM31.5 7l6.8 6.8h-6.8V7zm21.7-5v3.9h-4v11.8h3V8.9h1V53l5.4 10.9L64 53V2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();