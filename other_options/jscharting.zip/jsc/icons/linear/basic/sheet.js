(function() { const icons = { "linear/basic/sheet": "M7.9 64V14.6L22.5 0h33.6v64H7.9zm13.8-50.2V5L13 13.7h8.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();