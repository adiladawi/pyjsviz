(function() { const icons = { "linear/basic/smartphone": "M32 56.1c-.3 0-.5.2-.5.5s.2.5.5.5.5-.2.5-.5-.2-.5-.5-.5zM14.8 0v64h34.5V0H14.8zm12.8 3.9h8.9v3h-8.9v-3zM32 60.1c-1.9 0-3.4-1.5-3.4-3.4s1.5-3.4 3.4-3.4 3.4 1.5 3.4 3.4c0 1.8-1.5 3.4-3.4 3.4zm14.3-10.9H17.7V10.8h28.6v38.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();