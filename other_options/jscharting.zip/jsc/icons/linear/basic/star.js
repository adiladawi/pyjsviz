(function() { const icons = { "linear/basic/star": "M32-2l-8.7 25H-.9l19.7 15.4L10 64.7l22-16.5 22 16.5-8.8-26.4L64.9 23H40.7L32-2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();