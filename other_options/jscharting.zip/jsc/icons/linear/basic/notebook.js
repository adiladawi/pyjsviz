(function() { const icons = { "linear/basic/notebook": "M15.8 6.9H6.9v3h8.9v-3zm0 39.4H6.9v3h8.9v-3zm0-31.5H6.9v3h8.9v-3zm0 39.4H6.9v3h8.9v-3zm0-23.7H6.9v3h8.9v-3zm0 7.9H6.9v3h8.9v-3zM9.8 0v4.9h7.9v7H9.8v.9h7.9v7H9.8v.9h7.9v7H9.8v.9h7.9v7H9.8v.9h7.9v7H9.8v.9h7.9v7H9.8v.9h7.9v7H9.8V64h44.3V0H9.8zm41.4 61h-8.9V3h8.9v58zM15.8 22.6H6.9v3h8.9v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();