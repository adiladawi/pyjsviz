(function() { const icons = { "linear/basic/book-pencil": "M53.2 0v54l5.4 10.8L64 54V0H53.2zM61 9.9h-4.9V3H61v6.9zM0 0v64h48.2V0H0zm7.9 61.1H3V3h4.9v58.1zm34.6-38.6h-29v-3h29v3zm0-6h-29v-3h29v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();