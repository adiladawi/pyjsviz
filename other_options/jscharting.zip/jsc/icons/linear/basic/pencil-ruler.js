(function() { const icons = { "linear/basic/pencil-ruler": "M0 0v21.4h8.7v2.9H0v4.8h6.8V32H0v4.8h8.7v2.9H0v4.8h6.8v2.9H0v4.8h8.7v2.9H0V64h64L0 0zm12.6 27.1l28.2 28.2H12.6V27.1zM53 44.5L16.8 8.3 24.7.4l36.2 36.2 2.6 10.5L53 44.5zM24.7 12.1l3.8-3.8-3.8-3.8-3.8 3.8 3.8 3.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();