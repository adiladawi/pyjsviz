(function() { const icons = { "linear/basic/mouse": "M33.5 19.7h15.8v-2.5c0-9-6.9-16.4-15.8-17.2v19.7zm-3 0V.1c-8.8.8-15.8 8.2-15.8 17.2v2.5h15.8zm-15.7 2.9v24.1C14.8 56.3 22.5 64 32 64s17.2-7.7 17.2-17.2V22.6H14.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();