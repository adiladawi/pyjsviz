(function() { const icons = { "linear/basic/mail-multiple": "M52.3 16.7H1.7l25.4 14.6 25.2-14.6zM0 19.1v32.1h54.2V19L27.1 34.7 0 19.1zM8.9 7.8v6.9h47.3v27.6H64V7.8H8.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();