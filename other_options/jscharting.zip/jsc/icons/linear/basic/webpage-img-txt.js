(function() { const icons = { "linear/basic/webpage-img-txt": "M0 5.9v52.2h64V5.9H0zm21.7 3.9h4.9v3h-4.9v-3zm-7.9 0h4.9v3h-4.9v-3zm-7.9 0h4.9v3H5.9v-3zM61 55.1H3V16.7h58v38.4zM33.5 39.3H5.9v3h27.6v-3zm24.6-15.7H36.4v18.7h21.7V23.6zm-3 15.8H39.4V26.6h15.7v12.8zM33.5 23.6H5.9v3h27.6v-3zm0 7.9H5.9v3h27.6v-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();