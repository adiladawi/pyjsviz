(function() { const icons = { "linear/basic/mail-open": "M0 64V25.1L9.8 21V0h44.3v21l9.8 4.1V64H0zm32-20.5l19.2-12V3H12.8v28.5l19.2 12zm22.2-13.9l5.2-3.2-5.2-2.2v5.4zm-44.4 0v-5.4l-5.2 2.2 5.2 3.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();