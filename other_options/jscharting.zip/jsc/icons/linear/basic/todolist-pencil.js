(function() { const icons = { "linear/basic/todolist-pencil": "M53.2 0v54l5.4 10.8L64 54V0H53.2zM61 9.9h-4.9V3H61v6.9zm-28.8-6h-3.6V0H17.7v3.9h-3.6l-.7 3H0V64h46.3V6.9H32.9l-.7-3zM12.8 55.1H7.9v-3h4.9v3zm0-9.8H7.9v-3h4.9v3zm0-9.8H7.9v-3h4.9v3zm0-9.9H7.9v-3h4.9v3zm3.6-18.7h4.3V3h4.9v3.9h4.3l1.2 4.9H15.2l1.2-4.9zm22 48.2H15.8v-3h22.6v3zm0-9.8H15.8v-3h22.6v3zm0-9.8H15.8v-3h22.6v3zm0-9.9H15.8v-3h22.6v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();