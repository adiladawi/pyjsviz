(function() { const icons = { "linear/basic/spread-bookmark": "M64 54.5l-30.9 4v-49l9.6-1.2v20.2l5.3-2.7 5.3 2.7V6.9L64 5.5v49zM44.8 8l6.4-.8V25L48 23.3l-3.2 1.6V8zM0 5.5l30.9 4v49L0 54.5v-49z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();