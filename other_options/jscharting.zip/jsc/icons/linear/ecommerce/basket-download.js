(function() { const icons = { "linear/ecommerce/basket-download": "M50.4 23.8l-7.6-19-2.7 1.1 7.2 17.9H16.7L23.8 6l-2.7-1.1-7.5 18.9H0l11.6 35.8h40.8L64 23.8H50.4zM32.9 53.2h-1.8l-8.5-8.5 2.1-2.1 5.8 5.8V31.5h3v16.9l5.8-5.8 2.1 2.1-8.5 8.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();