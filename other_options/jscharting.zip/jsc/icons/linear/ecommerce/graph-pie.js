(function() { const icons = { "linear/ecommerce/graph-pie": "M29 8h-1c-7.5 0-14.6 2.9-19.8 8.2C2.9 21.5 0 28.5 0 36s2.9 14.5 8.2 19.8S20.5 64 28 64s14.5-2.9 19.8-8.2S56 43.5 56 36v-1H29V8zm26.8.2C50.6 2.9 43.5 0 36 0h-1v29h29v-1c0-7.5-2.9-14.5-8.2-19.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();