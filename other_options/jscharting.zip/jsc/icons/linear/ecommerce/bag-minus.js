(function() { const icons = { "linear/ecommerce/bag-minus": "M43.3 16.7v-5.4C43.3 5.1 38.2 0 32 0S20.7 5.1 20.6 11.3v5.4H8.9V64h46.3V16.7H43.3zm-19.7-5.3C23.6 6.8 27.4 3 32 3s8.4 3.7 8.4 8.3v5.4H23.6v-5.3zm17.9 32.1h-19v-3h19v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();