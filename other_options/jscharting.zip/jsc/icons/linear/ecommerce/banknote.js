(function() { const icons = { "linear/ecommerce/banknote": "M0 14.8v34.5h64V14.8H0zm60 25.6h-1.4c-1.9 0-3.4 1.5-3.4 3.4v1.5H8.9v-1.5c0-1.9-1.5-3.4-3.4-3.4H3.9V23.6h1.5c1.9 0 3.4-1.5 3.4-3.4v-1.5h46.3v1.5c0 1.9 1.5 3.4 3.4 3.4H60v16.8zM32 22.6c-5.2 0-9.4 4.2-9.4 9.4s4.2 9.4 9.4 9.4 9.4-4.2 9.4-9.4-4.2-9.4-9.4-9.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();