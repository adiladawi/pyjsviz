(function() { const icons = { "linear/ecommerce/creditcard": "M41.3 45.3H11.8v3h29.5v-3zm-30.5 0H5.9v3h4.9v-3zM0 9.8v44.3h64V9.8H0zm61 41.4H3V26.6h58v24.6zm0-35.4H3v-3h58v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();