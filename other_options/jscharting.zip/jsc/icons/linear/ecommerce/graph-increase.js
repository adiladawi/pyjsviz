(function() { const icons = { "linear/ecommerce/graph-increase": "M8.9 64h14.8V43.3H8.9V64zM15 39.3L49.2 5.1v7.7h3V1.3L50.9 0H39.4v3h7.7L12.9 37.2l2.1 2.1zM24.6 64h14.8V30.5H24.6V64zm15.8-47.3V64h14.8V16.7H40.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();