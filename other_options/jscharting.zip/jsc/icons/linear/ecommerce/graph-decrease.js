(function() { const icons = { "linear/ecommerce/graph-decrease": "M24.6 64h14.8V30.5H24.6V64zM8.8 64h14.8V14.7H8.8V64zm31.6 0h14.8V43.3H40.4V64zm11.8-36.4v7.7L16.9 0l-2.1 2.1 35.3 35.3h-7.7v3h11.5l1.3-1.3V27.6h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();