(function() { const icons = { "linear/ecommerce/basket-minus": "M50.4 23.8L42.9 4.9 40.2 6l7.1 17.8H16.7L23.8 6l-2.7-1.2-7.6 19H0l11.6 35.8h40.8L64 23.8H50.4zm-8.9 20.7h-19v-3h19v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();