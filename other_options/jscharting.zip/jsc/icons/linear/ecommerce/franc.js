(function() { const icons = { "linear/ecommerce/franc": "M54.6 9.4C48.6 3.3 40.5 0 32 0S15.4 3.3 9.4 9.4C3.3 15.4 0 23.5 0 32c0 8.5 3.3 16.6 9.4 22.6 6 6 14.1 9.4 22.6 9.4s16.6-3.3 22.6-9.4c6-6 9.4-14.1 9.4-22.6 0-8.5-3.3-16.6-9.4-22.6zM41.5 19.5h-15v11h13v3h-13v3h8v3h-8v9h-3v-9h-4v-3h4v-20h18v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();