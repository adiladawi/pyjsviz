(function() { const icons = { "linear/ecommerce/basket-plus": "M50.4 23.8l-7.6-19-2.7 1.1 7.2 17.9H16.7L23.8 6l-2.7-1.1-7.5 18.9H0l11.6 35.8h40.8L64 23.8H50.4zm-8.9 20.7h-8v8h-3v-8h-8v-3h8v-8h3v8h8v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();