(function() { const icons = { "linear/ecommerce/basket": "M50.4 23.5L42.9 4.6l-2.7 1.1 7.1 17.8H16.7l7.1-17.8-2.7-1.1-7.5 18.9H0l11.6 35.9h40.8L64 23.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();