(function() { const icons = { "linear/ecommerce/megaphone": "M35 17h9v24h-9zM60.7 4L46 15.3v27.4L60.7 54H64V4zM6.6 16L0 22.6v12.8L6.6 42h11l-7 18h8.1l10-18H33V16H6.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();