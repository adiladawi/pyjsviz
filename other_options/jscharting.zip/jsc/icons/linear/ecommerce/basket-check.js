(function() { const icons = { "linear/ecommerce/basket-check": "M50.4 23.5L42.9 4.6l-2.7 1.1 7.1 17.8H16.7l7.1-17.8-2.7-1.1-7.5 18.9H0l11.6 35.8h40.8L64 23.5H50.4zM30.9 49.2h-1.8l-7.5-7.5 2.1-2.1 6.3 6.3 12.3-12.3 2.1 2.1-13.5 13.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();