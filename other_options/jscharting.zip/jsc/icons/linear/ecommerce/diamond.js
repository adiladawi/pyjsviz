(function() { const icons = { "linear/ecommerce/diamond": "M16.7 6.6L0 27.2h14.6l5.9-20.6zM.5 30.7l26.8 26.7-12.5-26.7zm17.7-3.5h12.1V6.6h-6.2zm12.1 3.5H18.6l11.7 25zm17-24.1h-3.8l5.9 20.6H64zM33.7 30.7v25l11.7-25zm0-24.1v20.6h12.1L39.9 6.6zm3 50.8l26.8-26.7H49.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();