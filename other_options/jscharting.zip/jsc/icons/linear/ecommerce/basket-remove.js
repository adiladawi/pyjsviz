(function() { const icons = { "linear/ecommerce/basket-remove": "M50.4 23.8l-7.6-19-2.7 1.1 7.2 17.9H16.7L23.8 6l-2.7-1.1-7.5 18.9H0l11.6 35.8h40.8L64 23.8H50.4zm-10 25.5l-2.1 2.1-6.3-6.3-6.3 6.3-2.1-2.1 6.3-6.3-6.3-6.3 2.1-2.1 6.3 6.3 6.3-6.3 2.1 2.1-6.3 6.3 6.3 6.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();