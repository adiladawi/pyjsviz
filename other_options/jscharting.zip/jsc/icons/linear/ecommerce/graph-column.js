(function() { const icons = { "linear/ecommerce/graph-column": "M23 64H9V28h14v36zm32 0H41V38h14v26zm-16 0H25V0h14v64z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();