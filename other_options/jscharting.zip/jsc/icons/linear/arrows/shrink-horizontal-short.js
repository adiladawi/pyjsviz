(function() { const icons = { "linear/arrows/shrink-horizontal-short": "M57.1 64V33.5H41.5l4.7 4.7-2.2 2.1-7.5-7.4v-1.8l7.5-7.4 2.2 2.1-4.7 4.7h15.6V0h3v64h-3zM3.9 64V0h3v30.5h15.6l-4.7-4.7 2.2-2.1 7.5 7.4v1.8L20 40.3l-2.3-2.1 4.7-4.7H6.9V64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();