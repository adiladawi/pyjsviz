(function() { const icons = { "linear/arrows/square-right": "M0 0v64h64V0H0zm45.5 32.9L27.9 50.4l-2.3-2.1L41.9 32 25.6 15.7l2.3-2.1 17.6 17.5v1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();