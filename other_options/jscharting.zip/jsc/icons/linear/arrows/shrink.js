(function() { const icons = { "linear/arrows/shrink": "M42.4 44.5v7.8h-3V40.7l1.3-1.3h11.6v3h-7.8L64 61.9 61.9 64 42.4 44.5zM0 61.9l19.5-19.5h-7.8v-3h11.6l1.3 1.3v11.6h-3v-7.8L2.1 64 0 61.9zm40.7-37.3l-1.3-1.3V11.8h3v7.8L61.9 0 64 2.1 44.5 21.6h7.8v3H40.7zm-28.9 0v-3h7.8L0 2.1 2.1 0l19.5 19.5v-7.8h3v11.6l-1.3 1.3H11.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();