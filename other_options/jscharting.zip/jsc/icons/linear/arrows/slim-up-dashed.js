(function() { const icons = { "linear/arrows/slim-up-dashed": "M30.5 52.2h3v-4.9h-3v4.9zm0-5.9h3v-4.9h-3v4.9zm0 17.7h3v-4.9h-3V64zm0-23.6h3v-4.9h-3v4.9zm0 17.7h3v-4.9h-3v4.9zm0-47.3h3V5.9h-3v4.9zm0 5.9h3v-4.9h-3v4.9zm0 17.8h3v-4.9h-3v4.9zm0-11.9h3v-4.9h-3v4.9zm0 6h3v-4.9h-3v4.9zM32.9 0h-1.8l-9.3 9.5 2 2.2 6.8-6.8h2.8l6.8 6.8 2-2.2L32.9 0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();