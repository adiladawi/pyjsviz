(function() { const icons = { "linear/arrows/glide-horizontal": "M44.4 48.1l16-16.1-16-16.1 2.3-2L64 31.1v1.8L46.7 50.1l-2.3-2zM0 32.8V31l17.3-17.2 2.2 2-16 16.1 16 16.1-2.2 2L0 32.8zm32 5.6c-3.5 0-6.4-2.9-6.4-6.4s2.9-6.4 6.4-6.4 6.4 2.9 6.4 6.4-2.9 6.4-6.4 6.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();