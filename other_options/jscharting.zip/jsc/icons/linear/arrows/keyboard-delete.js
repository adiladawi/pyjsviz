(function() { const icons = { "linear/arrows/keyboard-delete": "M19.7 42.5h33.8v-21H19.7L11 32l8.7 10.5zm5.9-16.8l2.1-2.1 6.3 6.3 6.3-6.3 2.1 2.1-6.3 6.3 6.3 6.3-2.1 2.1-6.3-6.3-6.3 6.3-2.1-2.1 6.3-6.3-6.3-6.3zM63 0H1L0 1v62l1 1h62l1-1V1l-1-1zm-6.5 45.5H18.3L7 32l11.3-13.5h38.2v27z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();