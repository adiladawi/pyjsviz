(function() { const icons = { "linear/arrows/move-right": "M56.6 64V0h3v64h-3zM41.9 38.2l4.7-4.7H4.4v-3h42.2L42 25.8l2.2-2.1 7.5 7.4v1.8l-7.5 7.4-2.3-2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();