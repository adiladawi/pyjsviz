(function() { const icons = { "linear/arrows/circle-plus": "M54.6 9.4C48.6 3.3 40.5 0 32 0 23.5 0 15.4 3.3 9.4 9.4 3.3 15.4 0 23.5 0 32s3.3 16.6 9.4 22.6c6 6 14.1 9.4 22.6 9.4 8.5 0 16.6-3.3 22.6-9.4 6-6 9.4-14.1 9.4-22.6 0-8.5-3.3-16.6-9.4-22.6zm-4.1 24.1h-17v17h-3v-17h-17v-3h17v-17h3v17h17v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();