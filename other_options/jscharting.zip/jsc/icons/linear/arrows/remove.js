(function() { const icons = { "linear/arrows/remove": "M17.6 44.3L29.9 32 17.5 19.8l2.1-2.2L32 29.9l12.2-12.4 2.2 2.2L34.1 32l12.4 12.2-2.2 2.2L32 34.1 19.8 46.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();