(function() { const icons = { "linear/arrows/sign-left": "M18.6 14L-.5 32l19.1 18H64V14H18.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();