(function() { const icons = { "linear/arrows/shrink-horizontal": "M36.4 32.9v-1.8l7.5-7.4 2.3 2.1-4.7 4.7H64v3H41.5l4.7 4.7-2.2 2.1-7.6-7.4zm-18.6 5.3l4.7-4.7H0v-3h22.5l-4.7-4.7 2.3-2.1 7.5 7.4v1.8l-7.5 7.4-2.3-2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();