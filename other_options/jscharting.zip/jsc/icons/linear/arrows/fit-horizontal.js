(function() { const icons = { "linear/arrows/fit-horizontal": "M61 64V0h3v64h-3zM0 64V0h3v64H0zm46.3-25.8l4.7-4.7H12.9l4.7 4.7-2.3 2.1-7.5-7.4v-1.8l7.5-7.4 2.3 2.1-4.7 4.7h38.2l-4.7-4.7 2.2-2.1 7.5 7.4v1.8l-7.5 7.4-2.3-2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();