(function() { const icons = { "linear/arrows/expand": "M51.2 64v-3H59L40.5 42.5l2.1-2.1L61 59v-7.8h3v11.5L62.7 64H51.2zM1.3 64L0 62.7V51.2h3V59l18.5-18.5 2.1 2.1L5 61h7.8v3H1.3zm39.2-42.5L59 3h-7.8V0h11.5L64 1.3v11.5h-3V5L42.5 23.5l-2-2zM3 5v7.8H0V1.3L1.3 0h11.5v3H5l18.5 18.5-2.1 2.1L3 5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();