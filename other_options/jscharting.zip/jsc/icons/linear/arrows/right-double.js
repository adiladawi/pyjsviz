(function() { const icons = { "linear/arrows/right-double": "M31.9 13.6l-2.3 2.1L45.9 32 29.6 48.3l2.3 2.1 17.6-17.5v-1.8L31.9 13.6zm2.6 17.5L16.9 13.6l-2.2 2.1L30.9 32 14.6 48.3l2.3 2.1 17.6-17.5v-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();