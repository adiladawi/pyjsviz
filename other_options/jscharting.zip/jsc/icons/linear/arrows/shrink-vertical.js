(function() { const icons = { "linear/arrows/shrink-vertical": "M30.5 64V41.5l-4.7 4.7-2.1-2.2 7.4-7.5h1.8l7.4 7.5-2.1 2.3-4.7-4.7V64h-3zm.6-36.4l-7.4-7.5 2.1-2.3 4.7 4.7V0h3v22.5l4.7-4.7 2.1 2.2-7.4 7.5h-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();