(function() { const icons = { "linear/arrows/slide-upleft": "M0 37.4v-1.8l9.5-9.4 2.2 2.1L5 35h56V17.3h3V38H5l6.7 6.7-2.2 2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();