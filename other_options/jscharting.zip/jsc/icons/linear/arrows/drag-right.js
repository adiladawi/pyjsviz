(function() { const icons = { "linear/arrows/drag-right": "M16.3 48.3C7.3 48.3 0 41 0 32s7.3-16.3 16.3-16.3c8.4 0 15.4 6.5 16.1 14.8h26.7l-6.7-6.7 2.2-2.1 9.5 9.4v1.8l-9.4 9.3-2.3-2 6.7-6.7H32.4c-.7 8.3-7.7 14.8-16.1 14.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();