(function() { const icons = { "linear/arrows/slide-rightdown": "M26.6 64l-9.3-9.5 2-2.2L26 59V0h20.7v3H29v56l6.7-6.7 2.1 2.2-9.4 9.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();