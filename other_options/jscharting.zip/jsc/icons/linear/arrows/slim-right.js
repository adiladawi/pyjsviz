(function() { const icons = { "linear/arrows/slim-right": "M52.3 40.2l6.7-6.7H0v-3h59l-6.7-6.7 2.2-2 9.5 9.3v1.8l-9.5 9.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();