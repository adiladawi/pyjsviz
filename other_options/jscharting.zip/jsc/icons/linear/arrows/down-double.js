(function() { const icons = { "linear/arrows/down-double": "M31.9 45.9L15.6 29.6l-2.1 2.3L31 49.5h1.9l17.4-17.6-2.1-2.2-16.3 16.2zm1-11.4l17.4-17.6-2.1-2.2-16.3 16.2-16.3-16.3-2.1 2.3L31 34.5h1.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();