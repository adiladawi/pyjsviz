(function() { const icons = { "linear/arrows/expand-vertical": "M31.1 64l-7.4-7.5 2.1-2.3 4.7 4.7V44.3H0v-3h64v3H33.5V59l4.7-4.7 2.1 2.2-7.4 7.5h-1.8zM0 22.6v-3h30.5V5l-4.7 4.7-2.1-2.2L31.1 0h1.8l7.4 7.5-2.1 2.3L33.5 5v14.7H64v3H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();