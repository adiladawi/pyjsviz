(function() { const icons = { "linear/arrows/fit-vertical": "M0 64v-3h64v3H0zm31.1-7.9l-7.4-7.5 2.1-2.3 4.7 4.7V12.9l-4.7 4.7-2.1-2.2 7.4-7.5h1.8l7.4 7.5-2.1 2.3-4.7-4.7v38.2l4.7-4.7 2.1 2.2-7.4 7.5h-1.8zM0 3V0h64v3H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();