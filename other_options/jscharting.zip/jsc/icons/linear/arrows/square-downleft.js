(function() { const icons = { "linear/arrows/square-downleft": "M0 0v64h64V0H0zm47.5 42.5H22.8l-1.3-1.3V16.5h3v23h23v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();