(function() { const icons = { "linear/arrows/expand-horizontal": "M41.4 64V0h3v30.5H59l-4.7-4.7 2.2-2.1 7.5 7.4v1.8l-7.5 7.4-2.3-2.1 4.7-4.7H44.3V64h-2.9zm-21.7 0V33.5H5l4.7 4.7-2.2 2.1L0 32.9v-1.8l7.5-7.4 2.2 2.1L5 30.5h14.7V0h3v64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();