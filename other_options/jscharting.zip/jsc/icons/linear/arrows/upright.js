(function() { const icons = { "linear/arrows/upright": "M39.5 47.5v-23h-23v-3h24.7l1.3 1.3v24.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();