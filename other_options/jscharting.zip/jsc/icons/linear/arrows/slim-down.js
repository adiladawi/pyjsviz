(function() { const icons = { "linear/arrows/slim-down": "M31.1 64l-9.3-9.5 2-2.2 6.7 6.7V0h3v59l6.7-6.7 2 2.2-9.3 9.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();