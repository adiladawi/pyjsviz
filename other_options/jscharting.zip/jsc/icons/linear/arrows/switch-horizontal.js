(function() { const icons = { "linear/arrows/switch-horizontal": "M52.4 50l6.6-6.7H8.9v-3H59l-6.6-6.7 2.1-2.1 9.5 9.3v1.8l-9.5 9.3-2.1-1.9zM0 23.1v-1.8L9.5 12l2.2 2.1-6.6 6.7h50v3h-50l6.6 6.7-2.2 2.1L0 23.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();