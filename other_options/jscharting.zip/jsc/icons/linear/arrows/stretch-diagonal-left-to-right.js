(function() { const icons = { "linear/arrows/stretch-diagonal-left-to-right": "M1.3 64L0 62.7V51.2h3V59l22.4-22.4 2.1 2.1L5 61h7.8v3H1.3zm21.4-39.2l2.1-2.1 16.4 16.5-2.1 2.1-16.4-16.5zm13.8.6L59 3h-7.8V0h11.5L64 1.3v11.5h-3V5L38.6 27.5l-2.1-2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();