(function() { const icons = { "linear/arrows/slim-left-dashed": "M29.5 33.5h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3zm-1 0v-3H5.9v3h4.9zm24.6 0h4.9v-3h-4.9v3zm23.7-3v3H64v-3h-4.9zm-5.9 3h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3zM9.5 21.8L0 31.1v1.8l9.5 9.3 2.2-2-6.8-6.8v-2.8l6.8-6.8-2.2-2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();