(function() { const icons = { "linear/arrows/button-on": "M47 15H17C7.6 15 0 22.6 0 32s7.6 17 17 17h30c9.4 0 17-7.6 17-17s-7.6-17-17-17zm0 30c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();