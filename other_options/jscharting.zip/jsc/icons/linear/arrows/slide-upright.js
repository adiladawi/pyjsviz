(function() { const icons = { "linear/arrows/slide-upright": "M52.3 44.7L59 38H0V17.3h3V35h56l-6.7-6.7 2.2-2.1 9.5 9.4v1.8l-9.5 9.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();