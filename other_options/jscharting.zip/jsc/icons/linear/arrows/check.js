(function() { const icons = { "linear/arrows/check": "M24.1 46.5L11.6 33.9l2.1-2.3L25 42.9l23.3-23.2 2.1 2.2-24.5 24.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();