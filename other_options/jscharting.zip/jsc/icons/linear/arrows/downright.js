(function() { const icons = { "linear/arrows/downright": "M16.5 42.5v-3h23v-23h3v24.7l-1.3 1.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();