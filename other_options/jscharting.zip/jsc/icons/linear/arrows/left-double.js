(function() { const icons = { "linear/arrows/left-double": "M34.4 15.6l-2.3-2.1L14.5 31v1.9l17.6 17.4 2.2-2.1L18 31.9l16.4-16.3zm14.9 0l-2.2-2.1L29.5 31v1.9l17.6 17.4 2.2-2.1L33 31.9l16.3-16.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();