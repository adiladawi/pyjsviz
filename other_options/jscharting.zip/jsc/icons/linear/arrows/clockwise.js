(function() { const icons = { "linear/arrows/clockwise": "M32 64C14.4 64 0 49.6 0 32S14.4 0 32 0s32 14.4 32 32c0 6.7-2.1 13.1-5.9 18.6l-.1.2-3.4 3.4H62v3H50.5l-1.3-1.3V44.3h3v8l3.6-3.6C59.2 43.9 61 38.1 61 32 61 16 48 3 32 3S3 16 3 32s13 29 29 29h.5v3H32z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();