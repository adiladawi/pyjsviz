(function() { const icons = { "linear/arrows/drag-up-dashed": "M33.5 16.8h-3v4.9h3v-4.9zm-3 10.8h3v-4.9h-3v4.9zm3.1 4.1v-3.1h-3v3.1c-8.4.7-14.8 7.7-14.8 16.1C15.8 56.7 23 64 32 64s16.2-7.3 16.4-16.2c0-8.4-6.5-15.4-14.8-16.1zm-.1-20.8h-3v4.9h3v-4.9zm-3-5.9v4.8h3V5l6.7 6.7 2-2.3L32.9 0h-1.8l-9.3 9.4 2 2.2L30.5 5zm1.1-1.1h.8l1 1h-2.8l1-1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();