(function() { const icons = { "linear/arrows/square-up": "M0 0v64h64V0H0zm48.3 41.4L32 25.1 15.7 41.3l-2.1-2.2 17.5-17.6h1.8l17.5 17.6-2.1 2.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();