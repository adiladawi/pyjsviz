(function() { const icons = { "linear/arrows/left": "M18.5 32.9v-1.8l17.6-17.5 2.2 2.1L22.1 32l16.2 16.3-2.2 2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();