(function() { const icons = { "linear/arrows/drag-right-dashed": "M16.2 15.8C7.3 15.8 0 23 0 32s7.3 16.2 16.2 16.2c8.4 0 15.4-6.4 16.1-14.6h3.1v-3h-3.1c-.7-8.4-7.7-14.8-16.1-14.8zm20.2 17.7h4.9v-3h-4.9v3zm16.7-3h-4.9v3h4.9v-3zm-10.8 3h4.9v-3h-4.9v3zm12.3-11.7l-2.3 2 6.7 6.7h-4.8v3H59l-6.7 6.7 2.3 2 9.4-9.3v-1.8l-9.4-9.3zm5.5 10.6l-1 1v-2.8l1 1v.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();