(function() { const icons = { "linear/arrows/sign-right": "M0 14v36h45.4l19.1-18-19.1-18H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();