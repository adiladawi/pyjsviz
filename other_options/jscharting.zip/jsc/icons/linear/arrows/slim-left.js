(function() { const icons = { "linear/arrows/slim-left": "M0 32.9v-1.8l9.5-9.3 2.2 2L5 30.5h59v3H5l6.7 6.7-2.2 2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();