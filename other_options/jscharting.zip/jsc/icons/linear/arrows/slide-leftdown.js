(function() { const icons = { "linear/arrows/slide-leftdown": "M35.6 64l-9.4-9.5 2.1-2.2L35 59V3H17.3V0H38v59l6.7-6.7 2 2.2-9.3 9.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();