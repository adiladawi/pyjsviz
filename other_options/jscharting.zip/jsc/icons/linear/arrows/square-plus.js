(function() { const icons = { "linear/arrows/square-plus": "M0 0v64h64V0H0zm50.5 33.5h-17v17h-3v-17h-17v-3h17v-17h3v17h17v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();