(function() { const icons = { "linear/arrows/slim-down-dashed": "M33.5 11.8h-3v4.9h3v-4.9zm0 17.8h-3v4.9h3v-4.9zm0-11.9h-3v4.9h3v-4.9zm0-17.7h-3v4.9h3V0zm0 5.9h-3v4.9h3V5.9zm0 17.8h-3v4.9h3v-4.9zm0 29.4h-3v2h3v-2zm0-5.8h-3v4.9h3v-4.9zm0-5.9h-3v4.9h3v-4.9zm0-5.9h-3v4.9h3v-4.9zm6.7 16.8L32 60.5l-8.2-8.2-2 2.2 9.3 9.5h1.8l9.3-9.5-2-2.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();