(function() { const icons = { "linear/arrows/diagonal-right-to-left": "M51.2 64v-3H59L3 5v7.8H0V1.3L1.3 0h11.5v3H5l56 56v-7.8h3v11.5L62.7 64z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();