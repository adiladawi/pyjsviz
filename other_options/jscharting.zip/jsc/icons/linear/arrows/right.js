(function() { const icons = { "linear/arrows/right": "M25.6 48.3L41.9 32 25.7 15.7l2.2-2.1 17.6 17.5v1.8L27.9 50.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();