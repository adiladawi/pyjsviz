(function() { const icons = { "linear/arrows/drag-up": "M32 64c-9 0-16.3-7.3-16.3-16.3 0-8.4 6.5-15.4 14.8-16.1V5l-6.7 6.6-2.1-2.2L31.1 0h1.8l9.3 9.4-2 2.3L33.5 5v26.7c8.3.7 14.8 7.7 14.8 16C48.3 56.7 41 64 32 64z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();