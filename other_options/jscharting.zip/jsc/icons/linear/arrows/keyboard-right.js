(function() { const icons = { "linear/arrows/keyboard-right": "M27.5 23.9v16.2L39.4 32l-11.9-8.1zM63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM43.5 33.1L26.8 44.4l-2.3-1.1V20.7l2.3-1.1 16.7 11.3v2.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();