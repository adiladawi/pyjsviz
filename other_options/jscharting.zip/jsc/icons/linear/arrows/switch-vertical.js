(function() { const icons = { "linear/arrows/switch-vertical": "M21.3 64L12 54.5l2.1-2.2 6.7 6.6-.2-50h3V59l6.7-6.7 2.1 2.2-9.3 9.5h-1.8zm19-8.9L40.4 5l-6.7 6.7-2.1-2.2L40.9 0h1.8L52 9.5l-2 2.2L43.3 5l-.1 50.1h-2.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();