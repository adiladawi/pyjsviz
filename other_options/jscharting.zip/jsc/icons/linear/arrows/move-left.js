(function() { const icons = { "linear/arrows/move-left": "M4.4 64V0h3v64h-3zm7.9-31.1v-1.8l7.5-7.4 2.3 2.1-4.7 4.7h42.2v3H17.4l4.7 4.7-2.3 2.1-7.5-7.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();