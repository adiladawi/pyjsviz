(function() { const icons = { "linear/arrows/stretch-diagonal-right-to-left": "M51.2 64v-3H59L36.5 38.6l2.1-2.1L61 59v-7.8h3v11.5L62.7 64H51.2zM22.7 39.2l16.5-16.5 2.1 2.1-16.5 16.5-2.1-2.1zM3 5v7.8H0V1.3L1.3 0h11.5v3H5l22.4 22.4-2.1 2.1L3 5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();