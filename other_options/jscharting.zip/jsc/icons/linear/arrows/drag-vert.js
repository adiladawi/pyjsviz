(function() { const icons = { "linear/arrows/drag-vert": "M0 41.4v-3h64v3H0zm0-7.9v-3h64v3H0zm0-7.9v-3h64v3H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();