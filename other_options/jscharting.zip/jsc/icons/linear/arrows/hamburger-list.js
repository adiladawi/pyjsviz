(function() { const icons = { "linear/arrows/hamburger-list": "M15.8 45.3v-3H64v3H15.8zM0 45.3v-3h6.9v3H0zm15.8-11.8v-3H64v3H15.8zM0 33.5v-3h6.9v3H0zm15.8-11.8v-3H64v3H15.8zM0 21.7v-3h6.9v3H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();