(function() { const icons = { "linear/arrows/stretch-diagonal-right-to-left-crossed": "M51.2 64v-3H59L32 34.1 2.2 63.9.1 61.8 29.9 32 3 5v7.8H0V1.3L1.3 0h11.5v3H5l27 26.9L61.8.1l2.1 2.1L34.1 32 61 59v-7.8h3v11.5L62.7 64z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();