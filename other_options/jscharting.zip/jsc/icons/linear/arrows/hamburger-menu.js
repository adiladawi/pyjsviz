(function() { const icons = { "linear/arrows/hamburger-menu": "M11.5 46.5v-3h41v3h-41zm0-12v-3h41v3h-41zm0-12v-3h41v3h-41z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();