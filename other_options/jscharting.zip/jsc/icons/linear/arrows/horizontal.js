(function() { const icons = { "linear/arrows/horizontal": "M0 32.9v-1.8l7.5-7.4 2.2 2.1L5 30.5h54l-4.7-4.7 2.2-2.1 7.5 7.4v1.8l-7.5 7.4-2.3-2.1 4.8-4.7H5l4.7 4.7-2.2 2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();