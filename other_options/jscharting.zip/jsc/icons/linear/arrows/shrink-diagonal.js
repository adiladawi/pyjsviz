(function() { const icons = { "linear/arrows/shrink-diagonal": "M0 61.9l25.5-25.5h-7.8v-3h11.6l1.3 1.3v11.6h-3v-7.8L2.1 64 0 61.9zm34.8-31.4l-1.3-1.3V17.7h3v7.8L61.9 0 64 2.1 38.5 27.6h7.8v3H34.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();