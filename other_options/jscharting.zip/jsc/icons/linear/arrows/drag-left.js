(function() { const icons = { "linear/arrows/drag-left": "M47.7 48.3c-8.4 0-15.4-6.5-16.1-14.8H5l6.6 6.7-2.2 2.1L0 32.9v-1.8l9.4-9.3 2.3 2L5 30.5h26.7c.7-8.3 7.7-14.8 16.1-14.8C56.7 15.7 64 23 64 32s-7.3 16.3-16.3 16.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();