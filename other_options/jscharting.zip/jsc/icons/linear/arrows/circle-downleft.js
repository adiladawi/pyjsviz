(function() { const icons = { "linear/arrows/circle-downleft": "M54.6 9.4C48.6 3.3 40.5 0 32 0 23.5 0 15.4 3.3 9.4 9.4 3.3 15.4 0 23.5 0 32c0 8.5 3.3 16.6 9.4 22.6 6 6 14.1 9.4 22.6 9.4 8.5 0 16.6-3.3 22.6-9.4 6-6 9.4-14.1 9.4-22.6 0-8.5-3.3-16.6-9.4-22.6zm-7.1 33.1H22.8l-1.3-1.3V16.5h3v23h23v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();