(function() { const icons = { "linear/arrows/stretch-vertical-crossed": "M31.1 64l-8.3-8.5 2-2.3 5.7 5.8V33.5H0v-3h30.5V5l-5.7 5.7-2.1-2.2L31.1 0h1.8l8.4 8.5-2.1 2.3L33.5 5v25.5H64v3H33.5V59l5.7-5.7 2.1 2.2-8.4 8.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();