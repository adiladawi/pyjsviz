(function() { const icons = { "linear/arrows/square-upleft": "M0 0v64h64V0H0zm47.5 24.5h-23v23h-3V22.8l1.3-1.3h24.7v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();