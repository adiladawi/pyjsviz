(function() { const icons = { "linear/arrows/plus": "M30.5 50.5v-17h-17v-3h17v-17h3v17h17v3h-17v17z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();