(function() { const icons = { "linear/arrows/move-top": "M30.5 59.6V17.3L25.8 22l-2.1-2.2 7.4-7.5h1.8l7.4 7.5-2.1 2.3-4.7-4.7v42.2h-3zM0 7.4v-3h64v3H0z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();