(function() { const icons = { "linear/arrows/stretch-vertical": "M31.1 64l-8.3-8.5 2.1-2.3 5.7 5.7V37.4h3V59l5.7-5.6 2.1 2.2-8.5 8.4h-1.8zM20.7 33.5v-3h22.6v3H20.7zm9.8-6.9V5l-5.7 5.6-2.1-2.2L31.1 0h1.8l8.3 8.5-2.1 2.3L33.5 5v21.5h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();