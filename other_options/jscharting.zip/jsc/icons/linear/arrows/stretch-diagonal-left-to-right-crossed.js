(function() { const icons = { "linear/arrows/stretch-diagonal-left-to-right-crossed": "M1.3 64L0 62.7V51.2h3V59l26.9-27L.1 2.2 2.2.1 32 29.9 59 3h-7.8V0h11.5L64 1.3v11.5h-3V5L34.1 32l29.8 29.8-2.1 2.1L32 34.1 5 61h7.8v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();