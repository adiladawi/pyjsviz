(function() { const icons = { "linear/arrows/move-bottom": "M0 59.6v-3h64v3H0zm31.1-7.9l-7.4-7.5 2.1-2.3 4.7 4.7V4.4h3v42.2l4.7-4.7 2.1 2.2-7.4 7.5h-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();