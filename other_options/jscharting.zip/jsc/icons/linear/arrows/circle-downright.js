(function() { const icons = { "linear/arrows/circle-downright": "M54.6 9.4C48.6 3.3 40.5 0 32 0 23.5 0 15.4 3.3 9.4 9.4 3.3 15.4 0 23.5 0 32c0 8.5 3.3 16.6 9.4 22.6 6 6 14.1 9.4 22.6 9.4 8.5 0 16.6-3.3 22.6-9.4 6-6 9.4-14.1 9.4-22.6 0-8.5-3.3-16.6-9.4-22.6zM42.5 41.2l-1.3 1.3H16.5v-3h23v-23h3v24.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();