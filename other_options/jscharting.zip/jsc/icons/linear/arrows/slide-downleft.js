(function() { const icons = { "linear/arrows/slide-downleft": "M61 46.7V29H5l6.7 6.7-2.2 2.1L0 28.4v-1.8l9.5-9.3 2.2 2L5 26h59v20.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();