(function() { const icons = { "linear/arrows/downleft": "M22.8 42.5l-1.3-1.3V16.5h3v23h23v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();