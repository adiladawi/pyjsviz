(function() { const icons = { "linear/arrows/square-check": "M0 0v64h64V0H0zm25.9 46.5h-1.8L11.6 33.9l2.1-2.3L25 42.9l23.3-23.2 2.1 2.2-24.5 24.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();