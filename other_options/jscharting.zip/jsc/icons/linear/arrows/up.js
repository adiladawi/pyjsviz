(function() { const icons = { "linear/arrows/up": "M13.6 39.1l17.5-17.6h1.8l17.5 17.6-2.1 2.2L32 25.1 15.7 41.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();