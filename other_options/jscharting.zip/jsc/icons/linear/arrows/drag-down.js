(function() { const icons = { "linear/arrows/drag-down": "M31.1 64l-9.3-9.4 2-2.3 6.7 6.7V32.4c-8.3-.7-14.8-7.7-14.8-16.1C15.7 7.3 23 0 32 0s16.3 7.3 16.3 16.3c0 8.4-6.5 15.4-14.8 16.1v26.7l6.7-6.7 2.1 2.2-9.4 9.4h-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();