(function() { const icons = { "linear/arrows/slim-up": "M30.5 64V5l-6.7 6.7-2-2.2L31.1 0h1.8l9.3 9.5-2 2.2L33.5 5v59z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();