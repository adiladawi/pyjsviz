(function() { const icons = { "linear/arrows/keyboard-up": "M23.9 38.5h16.2L32 26.6l-8.1 11.9zM63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM43.3 41.5H20.7l-1.1-2.3 11.3-16.7h2.2l11.3 16.7-1.1 2.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();