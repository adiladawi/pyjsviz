(function() { const icons = { "linear/arrows/keyboard-alt": "M63 0H1L0 1v62l1 1h62l1-1V1l-1-1zm-4.5 43.5H29.9l-1.1-.6-11.6-17.4H5.5v-3h12.6l1.1.6 11.6 17.4h27.7v3zm0-18h-29v-3h29v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();