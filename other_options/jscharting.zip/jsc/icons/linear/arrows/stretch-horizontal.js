(function() { const icons = { "linear/arrows/stretch-horizontal": "M30.5 43.3V20.7h3v22.6h-3zM0 32.9v-1.8l8.5-8.3 2.3 2.1L5 30.5h21.5v3H5l5.6 5.7-2.2 2.1L0 32.9zm53.2 6.3l5.7-5.7H37.4v-3H59l-5.7-5.7 2.3-2.1 8.5 8.3v1.8l-8.5 8.3-2.4-1.9z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();