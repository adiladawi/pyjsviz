(function() { const icons = { "linear/arrows/anticlockwise": "M31.5 64v-3h.5c16 0 29-13 29-29S48 3 32 3 3 16 3 32c0 6.1 1.8 11.9 5.3 16.8l3.5 3.5v-8h3v11.5l-1.3 1.3H2v-3h7.5L6 50.6C2.1 45.1 0 38.7 0 32 0 14.4 14.4 0 32 0s32 14.4 32 32-14.4 32-32 32h-.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();