(function() { const icons = { "linear/arrows/slide-leftup": "M17.3 64v-3H35V5l-6.7 6.7-2.1-2.2L35.6 0h1.8l9.3 9.5-2 2.2L38 5v59z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();