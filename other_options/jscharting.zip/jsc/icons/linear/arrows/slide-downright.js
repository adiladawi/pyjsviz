(function() { const icons = { "linear/arrows/slide-downright": "M0 46.7V26h59l-6.7-6.7 2.2-2 9.5 9.3v1.8l-9.5 9.4-2.2-2.1L59 29H3v17.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();