(function() { const icons = { "linear/arrows/shrink-diagonal-short": "M0 37.6l2.1-2.1 12.1 12.1 11.2-11.2h-7.8v-3h11.6l1.3 1.3v11.6h-3v-7.8L16.3 49.8l12.1 12.1-2 2.1L0 37.6zm34.8-7.1l-1.3-1.3V17.7h3v7.8l11.2-11.2L35.5 2.1 37.6 0 64 26.4l-2.1 2.1-12.1-12.2-11.3 11.3h7.8v3H34.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();