(function() { const icons = { "linear/arrows/expand-diagonal": "M26.1 40L5 61h7.8v3H1.3L0 62.7V51.2h3v7.7l21-21L.1 14l2.1-2.1 50.1 50-2.1 2.1-24.1-24zM11.9 2.2L14 .1 37.9 24 59 3h-7.8V0h11.5L64 1.3v11.5h-3V5.1l-21 21L63.9 50l-2.1 2.1L11.9 2.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();