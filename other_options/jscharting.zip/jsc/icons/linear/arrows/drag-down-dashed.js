(function() { const icons = { "linear/arrows/drag-down-dashed": "M30.5 47.3h3v-4.9h-3v4.9zm3-10.8h-3v4.9h3v-4.9zm-3 16.7h3v-4.9h-3v4.9zM32 0c-9 0-16.2 7.3-16.3 16.2 0 8.4 6.5 15.4 14.8 16.1v3.1h2.9v-3.1c8.3-.7 14.8-7.7 14.8-16.1C48.2 7.3 41 0 32 0zm1.5 59v-4.8h-3V59l-6.7-6.7-2 2.3 9.3 9.4h1.8l9.3-9.4-2-2.2-6.7 6.6zm-1.1 1.1h-.8l-1-1h2.8l-1 1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();