(function() { const icons = { "linear/arrows/keyboard-left": "M63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM39.5 43.3l-2.3 1.1-16.7-11.3v-2.2l16.7-11.3 2.3 1.1v22.6zm-3-3.2V23.9L24.6 32l11.9 8.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();