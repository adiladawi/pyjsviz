(function() { const icons = { "linear/arrows/slide-rightup": "M26 64V5l-6.7 6.7-2-2.2L26.6 0h1.8l9.4 9.5-2.1 2.2L29 5v56h17.7v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();