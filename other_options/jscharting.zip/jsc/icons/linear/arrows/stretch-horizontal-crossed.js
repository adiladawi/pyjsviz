(function() { const icons = { "linear/arrows/stretch-horizontal-crossed": "M30.5 64V33.5H5l5.7 5.7-2.2 2.1L0 32.9v-1.8l8.5-8.3 2.3 2L5 30.5h25.5V0h3v30.5H59l-5.8-5.7 2.3-2 8.5 8.3v1.8l-8.5 8.4-2.3-2.1 5.8-5.7H33.5V64z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();