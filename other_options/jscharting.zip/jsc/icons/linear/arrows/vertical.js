(function() { const icons = { "linear/arrows/vertical": "M31.1 64l-7.4-7.5 2.1-2.3 4.7 4.8V5l-4.7 4.7-2.1-2.2L31.1 0h1.8l7.4 7.5-2.1 2.3L33.5 5v54l4.7-4.7 2.1 2.2-7.4 7.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();