(function() { const icons = { "linear/arrows/square-downright": "M0 0v64h64V0H0zm42.5 41.2l-1.3 1.3H16.5v-3h23v-23h3v24.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();