(function() { const icons = { "linear/arrows/slim-right-dashed": "M17.7 33.5h4.9v-3h-4.9v3zm-11.8 0h4.9v-3H5.9v3zm17.7 0h4.9v-3h-4.9v3zm-11.8 0h4.9v-3h-4.9v3zm17.7 0h4.9v-3h-4.9v3zm11.9 0h4.9v-3h-4.9v3zm5.9 0h4.9v-3h-4.9v3zm5.9-3v3h4.9v-3h-4.9zm-17.8 3h4.9v-3h-4.9v3zM0 33.5h4.9v-3H0v3zm54.5-11.7l-2.2 2 6.8 6.8v2.8l-6.8 6.8 2.2 2 9.5-9.3v-1.8l-9.5-9.3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();