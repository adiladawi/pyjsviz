(function() { const icons = { "linear/arrows/info": "M54.6 9.4C48.6 3.3 40.5 0 32 0 23.5 0 15.4 3.3 9.4 9.4 3.3 15.4 0 23.5 0 32s3.3 16.6 9.4 22.6c6 6 14.1 9.4 22.6 9.4 8.5 0 16.6-3.3 22.6-9.4 6-6 9.4-14.1 9.4-22.6s-3.3-16.6-9.4-22.6zM33.5 47.5h-3v-23h3v23zm0-26h-3v-5h3v5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();