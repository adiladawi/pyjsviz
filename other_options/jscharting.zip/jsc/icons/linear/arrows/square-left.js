(function() { const icons = { "linear/arrows/square-left": "M0 0v64h64V0H0zm36.1 50.4L18.5 32.9v-1.8l17.6-17.5 2.2 2.1L22.1 32l16.3 16.3-2.3 2.1z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();