(function() { const icons = { "linear/arrows/up-double": "M32 18l16.3 16.3 2.1-2.2-17.5-17.6h-1.8L13.6 32.1l2.1 2.2L32 18zm-.9 11.5L13.6 47.1l2.1 2.2L32 33l16.3 16.3 2.1-2.2-17.5-17.6h-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();