(function() { const icons = { "linear/arrows/keyboard-down": "M32 39.4l8.1-11.9H23.9L32 39.4zM63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM33.1 43.5h-2.2L19.6 26.8l1.1-2.3h22.6l1.1 2.3-11.3 16.7z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();