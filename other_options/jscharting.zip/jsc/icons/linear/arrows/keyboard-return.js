(function() { const icons = { "linear/arrows/keyboard-return": "M63 0H1L0 1v62l1 1h62l1-1V1l-1-1zm-6.5 38.5H12.6l6.8 6.8-2.3 2.1-9.6-9.5v-1.8l9.6-9.5 2.3 2.1-6.8 6.8h40.9v-16h-10v-3h13v22z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();