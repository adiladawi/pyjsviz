(function() { const icons = { "linear/arrows/keyboard-tab": "M63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM47.5 32.9l-7.6 7.5-2.3-2.1 4.8-4.8H11.5v-3h30.9l-4.7-4.8 2.2-2.1 7.6 7.5v1.8zm4 8.6h-3v-19h3v19z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();