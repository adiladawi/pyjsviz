(function() { const icons = { "linear/arrows/squares": "M29 0H0v29h29V0zm6 29h29V0H35v29zm-6 6H0v29h29V35zm6 29h29V35H35v29z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();