(function() { const icons = { "linear/arrows/down": "M31.1 42.5L13.6 24.9l2.1-2.3L32 38.9l16.3-16.3 2.1 2.3-17.5 17.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();