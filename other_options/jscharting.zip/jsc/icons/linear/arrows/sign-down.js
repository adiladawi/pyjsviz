(function() { const icons = { "linear/arrows/sign-down": "M14 45.4l18 19.1 18-19.1V0H14v45.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();