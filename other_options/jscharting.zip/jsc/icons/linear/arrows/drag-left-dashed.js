(function() { const icons = { "linear/arrows/drag-left-dashed": "M9.8 33.5v-3H5l6.6-6.7-2.2-2L0 31.1v1.8l9.4 9.3 2.2-2L5 33.5h4.8zm-4.9-.1l-1-1v-.8l1-1v2.8zm5.9.1h4.9v-3h-4.9v3zm37-17.9c-8.4 0-15.4 6.5-16.1 14.8h-3.1v3h3.1c.7 8.3 7.7 14.8 16.1 14.8C56.7 48.2 64 41 64 32s-7.3-16.2-16.2-16.4zM22.6 33.5h4.9v-3h-4.9v3zm-5.9 0h4.9v-3h-4.9v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();