(function() { const icons = { "linear/arrows/drag-horiz": "M38.4 64V0h3v64h-3zm-7.9 0V0h3v64h-3zm-7.9 0V0h3v64h-3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();