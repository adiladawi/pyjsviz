(function() { const icons = { "linear/arrows/upleft": "M21.5 47.5V22.8l1.3-1.3h24.7v3h-23v23z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();