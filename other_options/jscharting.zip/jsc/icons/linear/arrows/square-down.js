(function() { const icons = { "linear/arrows/square-down": "M0 0v64h64V0H0zm32.9 42.5h-1.8L13.6 24.9l2.1-2.3L32 38.9l16.3-16.2 2.1 2.2-17.5 17.6z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();