(function() { const icons = { "linear/arrows/glide-vertical": "M31.1 64L13.9 46.6l2-2.3 16 16 16-15.9 2 2.2-17 17.4h-1.8zm.9-25.7c-3.5 0-6.4-2.9-6.4-6.4s2.9-6.4 6.4-6.4 6.4 2.9 6.4 6.4-2.9 6.4-6.4 6.4zm0-34.9l-16 16-2-2.2L31.1 0h1.8l17.2 17.3-2 2.2L32 3.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();