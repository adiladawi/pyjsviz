(function() { const icons = { "linear/arrows/button-up": "M32 0c-9.4 0-17 7.6-17 17v30c0 9.4 7.6 17 17 17s17-7.6 17-17V17c0-9.4-7.6-17-17-17zm0 30c-7.2 0-13-5.8-13-13S24.8 4 32 4s13 5.8 13 13-5.8 13-13 13z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();