(function() { const icons = { "linear/arrows/shrink-vertical-short": "M0 60.1v-3h30.5V41.5l-4.7 4.7-2.1-2.2 7.4-7.5h1.8l7.4 7.5-2.1 2.3-4.7-4.7v15.6H64v3H0zm31.1-32.5l-7.4-7.5 2.1-2.3 4.7 4.7V6.9H0v-3h64v3H33.5v15.6l4.7-4.7 2.1 2.2-7.4 7.5h-1.8z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();