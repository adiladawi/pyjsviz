(function() { const icons = { "linear/arrows/keyboard-shift": "M20.2 34.5h5l1.3 1.3v8.7h11v-8.7l1.3-1.3h5L32 20.3 20.2 34.5zM63 0H1L0 1v62l1 1h62l1-1V1l-1-1zM47.3 37.5h-6.8v8.7l-1.3 1.3H24.8l-1.3-1.3v-8.7h-6.8l-1-2.4L31 16.5h2l15.3 18.6-1 2.4z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();