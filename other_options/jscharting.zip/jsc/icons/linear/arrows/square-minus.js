(function() { const icons = { "linear/arrows/square-minus": "M0 0v64h64V0H0zm50.5 32.5h-37v-3h37v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();