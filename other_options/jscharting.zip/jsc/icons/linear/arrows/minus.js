(function() { const icons = { "linear/arrows/minus": "M13.5 29.5h37v3h-37z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();