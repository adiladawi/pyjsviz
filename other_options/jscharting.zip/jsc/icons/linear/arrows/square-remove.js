(function() { const icons = { "linear/arrows/square-remove": "M0 0v64h64V0H0zm44.3 44.5L32 32.2 19.8 44.6l-2.1-2.1 12.2-12.3-12.4-12.3 2.1-2.1L32 28l12.2-12.3 2.1 2.1-12.2 12.3 12.3 12.2-2.1 2.2z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();