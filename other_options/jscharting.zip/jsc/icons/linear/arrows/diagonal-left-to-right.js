(function() { const icons = { "linear/arrows/diagonal-left-to-right": "M1.3 64L0 62.7V51.2h3V59L59 3h-7.8V0h11.5L64 1.3v11.5h-3V5L5 61h7.8v3z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();