(function() { const icons = { "linear/arrows/sign-up": "M32-.5L14 18.6V64h36V18.6L32-.5z" };
if (JSC) {
	JSC.internal.registerIcons(icons);
}

})();