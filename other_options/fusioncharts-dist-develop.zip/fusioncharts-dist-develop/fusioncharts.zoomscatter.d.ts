
import { FusionChartStatic } from 'fusioncharts';

declare namespace Zoomscatter {}
declare var Zoomscatter: (H: FusionChartStatic) => FusionChartStatic;
export = Zoomscatter;
export as namespace Zoomscatter;

