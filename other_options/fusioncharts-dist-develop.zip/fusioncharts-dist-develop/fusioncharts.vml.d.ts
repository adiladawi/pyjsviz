
import { FusionChartStatic } from 'fusioncharts';

declare namespace Vml {}
declare var Vml: (H: FusionChartStatic) => FusionChartStatic;
export = Vml;
export as namespace Vml;

