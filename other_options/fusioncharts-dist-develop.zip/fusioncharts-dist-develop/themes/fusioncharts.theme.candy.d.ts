
import { FusionChartStatic } from 'fusioncharts';

declare namespace Candy {}
declare var Candy: (H: FusionChartStatic) => FusionChartStatic;
export = Candy;
export as namespace Candy;

