
import { FusionChartStatic } from 'fusioncharts';

declare namespace Gammel {}
declare var Gammel: (H: FusionChartStatic) => FusionChartStatic;
export = Gammel;
export as namespace Gammel;

