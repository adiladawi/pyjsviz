
import { FusionChartStatic } from 'fusioncharts';

declare namespace Fusion {}
declare var Fusion: (H: FusionChartStatic) => FusionChartStatic;
export = Fusion;
export as namespace Fusion;

