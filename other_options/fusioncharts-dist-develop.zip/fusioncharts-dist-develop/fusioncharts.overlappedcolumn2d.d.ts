
import { FusionChartStatic } from 'fusioncharts';

declare namespace Overlappedcolumn2d {}
declare var Overlappedcolumn2d: (H: FusionChartStatic) => FusionChartStatic;
export = Overlappedcolumn2d;
export as namespace Overlappedcolumn2d;

