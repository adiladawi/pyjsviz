
import { FusionChartStatic } from 'fusioncharts';

declare namespace Overlappedbar2d {}
declare var Overlappedbar2d: (H: FusionChartStatic) => FusionChartStatic;
export = Overlappedbar2d;
export as namespace Overlappedbar2d;

