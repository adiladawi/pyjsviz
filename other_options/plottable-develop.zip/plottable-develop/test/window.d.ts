// tslint:disable-next-line:interface-name
declare interface Window {
  PHANTOMJS: boolean;
  Pixel_CloseTo_Requirement: number;
}

declare var window: Window;
