<!--

Thanks for your interest in Plottable. For quickest turnaround on bugs, please create a live example
(jsfiddle, codepen, etc) that reproduces the faulty behavior.

Is this a support question? Please ask on the Gitter chat channel: gitter.im/palantir/plottable

Delete this template for feature requests.

-->

## Bug report

Live example URL:

Steps to repro:
1. <!-- fill this out -->
1. <!-- fill this out -->
1. <!-- fill this out -->

### Expected behavior
<!--- Tell us what should happen -->

### Actual behavior
<!--- Tell us what happens instead of the expected behavior -->

### Possible Solution
<!--- Not obligatory, but suggest a fix/reason for the bug -->

### Context
<!--- How has this issue affected you? What are you trying to accomplish? -->
<!--- Providing context helps us come up with a solution that is most useful in the real world -->

### Environment
<!--- Include as many relevant details about the environment you experienced the bug in -->

- Plottable version:
- Browser name/version:
- OS name/version:
