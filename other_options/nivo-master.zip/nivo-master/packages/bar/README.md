# `@nivo/bar`

[![version](https://img.shields.io/npm/v/@nivo/bar.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/bar)

## Bar

[documentation](http://nivo.rocks/bar)

![Bar](https://raw.githubusercontent.com/plouc/nivo/master/packages/bar/doc/bar.png)

## BarCanvas

[documentation](http://nivo.rocks/bar/canvas)

![BarCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/bar/doc/bar-canvas.png)
