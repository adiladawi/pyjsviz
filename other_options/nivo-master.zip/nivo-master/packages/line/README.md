# `@nivo/line`

[![version](https://img.shields.io/npm/v/@nivo/line.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/line)

## Line

[documentation](http://nivo.rocks/line/)

![Line](https://raw.githubusercontent.com/plouc/nivo/master/packages/line/doc/line.png)

## LineCanvas

[documentation](http://nivo.rocks/line/canvas/)

![LineCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/line/doc/line-canvas.png)
