# `@nivo/geo`

[![version](https://img.shields.io/npm/v/@nivo/geo.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/geo)

## GeoMap

[documentation](http://nivo.rocks/geomap)

![GeoMap](https://raw.githubusercontent.com/plouc/nivo/master/packages/geo/doc/geomap.png)

## GeoMapCanvas

[documentation](http://nivo.rocks/geomap/canvas)

![GeoMapCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/geo/doc/geomap-canvas.png)

## Choropleth

[documentation](http://nivo.rocks/choropleth)

![Choropleth](https://raw.githubusercontent.com/plouc/nivo/master/packages/geo/doc/choropleth.png)

## ChoroplethCanvas

[documentation](http://nivo.rocks/choropleth/canvas)

![ChoroplethCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/geo/doc/choropleth-canvas.png)
