# `@nivo/bullet`

[![version](https://img.shields.io/npm/v/@nivo/bullet.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/bullet)

## Bullet

[documentation](http://nivo.rocks/bullet)

![Bullet](https://raw.githubusercontent.com/plouc/nivo/master/packages/bullet/doc/bullet.png)
