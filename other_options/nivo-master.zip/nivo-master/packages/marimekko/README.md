# `@nivo/marimekko`

[![version](https://img.shields.io/npm/v/@nivo/marimekko.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/marimekko)

## Marimekko

[documentation](http://nivo.rocks/marimekko/)

![Marimekko](https://raw.githubusercontent.com/plouc/nivo/master/packages/marimekko/doc/marimekko.png)
