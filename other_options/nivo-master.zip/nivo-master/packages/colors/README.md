# `@nivo/colors`

[![version](https://img.shields.io/npm/v/@nivo/colors.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/colors)
