# `@nivo/generators`

[![version](https://img.shields.io/npm/v/@nivo/generators.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/generators)
