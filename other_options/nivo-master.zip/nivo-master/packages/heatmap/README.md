# `@nivo/heatmap`

[![version](https://img.shields.io/npm/v/@nivo/heatmap.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/heatmap)

## HeatMap

[documentation](http://nivo.rocks/heatmap)

![HeatMap](https://raw.githubusercontent.com/plouc/nivo/master/packages/heatmap/doc/heatmap.png)

## HeatMapCanvas

[documentation](http://nivo.rocks/heatmap/canvas)

![HeatmapCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/heatmap/doc/heatmap-canvas.png)
