# `@nivo/legends`

[![version](https://img.shields.io/npm/v/@nivo/legends.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/legends)
