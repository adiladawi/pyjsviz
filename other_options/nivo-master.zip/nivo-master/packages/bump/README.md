# `@nivo/bump`

[![version](https://img.shields.io/npm/v/@nivo/bump.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/bump)

## Bump

[documentation](http://nivo.rocks/bump/)

![Bump](https://raw.githubusercontent.com/plouc/nivo/master/packages/bump/doc/bump.png)

## AreaBump

[documentation](http://nivo.rocks/area-bump/)

![Bump](https://raw.githubusercontent.com/plouc/nivo/master/packages/bump/doc/area-bump.png)
