# `@nivo/core`

[![version](https://img.shields.io/npm/v/@nivo/core.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/core)
