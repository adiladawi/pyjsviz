# `@nivo/network`

[![version](https://img.shields.io/npm/v/@nivo/network.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/network)

## Network

[documentation](http://nivo.rocks/network/)

![Network](https://raw.githubusercontent.com/plouc/nivo/master/packages/network/doc/network.png)

## NetworkCanvas

[documentation](http://nivo.rocks/network/canvas/)

![NetworkCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/network/doc/network-canvas.png)
