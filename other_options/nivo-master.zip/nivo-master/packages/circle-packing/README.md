# `@nivo/circle-packing`

[![version](https://img.shields.io/npm/v/@nivo/circle-packing.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/circle-packing)

## Bubble

[documentation](http://nivo.rocks/bubble)

![Bubble](https://raw.githubusercontent.com/plouc/nivo/master/packages/circle-packing/doc/bubble.png)

## BubbleHtml

[documentation](http://nivo.rocks/bubble/html)

![BubbleHtml](https://raw.githubusercontent.com/plouc/nivo/master/packages/circle-packing/doc/bubble-html.png)

## BubbleCanvas

[documentation](http://nivo.rocks/bubble/canvas)

![BubbleCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/circle-packing/doc/bubble-canvas.png)
