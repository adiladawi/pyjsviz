# `@nivo/chord`

[![version](https://img.shields.io/npm/v/@nivo/chord.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/chord)

## Chord

[documentation](http://nivo.rocks/chord)

![Chord](https://raw.githubusercontent.com/plouc/nivo/master/packages/chord/doc/chord.png)

## ChordCanvas

[documentation](http://nivo.rocks/chord/canvas)

![ChordCanvas](https://raw.githubusercontent.com/plouc/nivo/master/packages/chord/doc/chord-canvas.png)
