# `@nivo/calendar`

[![version](https://img.shields.io/npm/v/@nivo/calendar.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/calendar)

## Calendar

[documentation](http://nivo.rocks/calendar)

![Calendar](https://raw.githubusercontent.com/plouc/nivo/master/packages/calendar/doc/calendar.png)
