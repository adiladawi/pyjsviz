# `@nivo/arcs`

[![version](https://img.shields.io/npm/v/@nivo/arcs.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/arcs)

This package is used internally by nivo packages dealing with arcs
such as `@nivo/pie`, `@nivo/chord` and `@nivo/sunburst`.
