# `@nivo/funnel`

[![version](https://img.shields.io/npm/v/@nivo/funnel.svg?style=flat-square)](https://www.npmjs.com/package/@nivo/funnel)

## Funnel

[documentation](http://nivo.rocks/funnel)

![Funnel](https://raw.githubusercontent.com/plouc/nivo/master/packages/funnel/doc/funnel.png)
