module.exports = {
    presets: [['react-app', { typescript: true }]]
}
