import React from 'react'

const Info = () => (
    <div className="Info">
        <div className="Links">
            <a>github</a>
            <a>twitter</a>
            <a>website</a>
        </div>
        <h1 className="Brand">nivo</h1>
    </div>
)

export default Info
