import React from 'react'
import './styles.css'

export default function App() {
    return (
        <div className="App">
            <h1>nivo</h1>
        </div>
    )
}
