

## Our Backers and supporters

Financial contributions to ApexCharts go towards ongoing development costs, servers, etc. You can join them in supporting ApexCharts development by visiting our page on [Patreon](https://www.patreon.com/junedchhipa)!


### Backers
Support us with a monthly donation and help us continue our activities. [[Become a backer](https://www.patreon.com/join/junedchhipa/checkout?rid=3043800)].

Backer on | Name
-----|-----
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Taillefer Brice
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Hugo Locurcio
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Aslan Mutaf
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Bob
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Pierre Aguilar
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Gergo Santha
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Xavier Trabet
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Christopher Bartling
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Andrew Pyle
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Victor Perrier
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  vicker
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  onepedia
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Johannes Goebel
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" />  Candin Jones
