// https://jestjs.io/docs/en/webpack#mocking-css-modules
module.exports = {};
