module.exports = {
  presets: [['@vue/app', { useBuiltIns: 'usage', corejs: 3 }]],
};
