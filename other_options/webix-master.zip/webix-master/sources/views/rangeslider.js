
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"rangeslider", defaults:{
	template:"GPL version doesn't support rangeslider <br> You need Webix PRO"
}}, template.view);