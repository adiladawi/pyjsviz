
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"panel", defaults:{
	template:"GPL version doesn't support panel <br> You need Webix PRO"
}}, template.view);