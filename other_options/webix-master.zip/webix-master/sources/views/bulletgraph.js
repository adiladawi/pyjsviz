
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"bulletgraph", defaults:{
	template:"GPL version doesn't support bulletgraph <br> You need Webix PRO"
}}, template.view);