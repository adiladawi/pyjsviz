
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"organogram", defaults:{
	template:"GPL version doesn't support organogram <br> You need Webix PRO"
}}, template.view);