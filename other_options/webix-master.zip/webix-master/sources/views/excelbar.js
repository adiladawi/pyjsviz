
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"excelbar", defaults:{
	template:"GPL version doesn't support excelbar <br> You need Webix PRO"
}}, template.view);