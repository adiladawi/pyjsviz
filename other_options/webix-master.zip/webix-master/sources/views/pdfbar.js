
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"pdfbar", defaults:{
	template:"GPL version doesn't support pdfbar <br> You need Webix PRO"
}}, template.view);