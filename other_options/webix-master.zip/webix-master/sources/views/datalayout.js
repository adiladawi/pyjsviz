
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"datalayout", defaults:{
	template:"GPL version doesn't support datalayout <br> You need Webix PRO"
}}, template.view);