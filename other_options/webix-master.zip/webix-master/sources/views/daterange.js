
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"daterange", defaults:{
	template:"GPL version doesn't support daterange <br> You need Webix PRO"
}}, template.view);