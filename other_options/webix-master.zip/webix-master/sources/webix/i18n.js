const i18n = {
	parseFormat:"%Y-%m-%d %H:%i:%s",
	parseTimeFormat:"%H:%i:%s",
};


export default i18n;