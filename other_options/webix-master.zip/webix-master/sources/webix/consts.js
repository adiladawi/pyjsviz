export const version="VERSION";
export const name = "core";