## Examples

```js
cy.$('#j').unlock();
```