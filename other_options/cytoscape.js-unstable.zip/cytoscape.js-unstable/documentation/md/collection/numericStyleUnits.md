## Details

- `px` for pixels
- `em` for ems
- `%` for percent
- `rad` for radians
- `s` for seconds
- `ms` for milliseconds
