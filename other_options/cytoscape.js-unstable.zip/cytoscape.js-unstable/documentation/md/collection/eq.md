## Details

<span class="important-indicator"></span> You may use `eles[i]` in place of `eles.eq(i)` as a more performant alternative.