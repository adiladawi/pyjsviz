## Details

While the segment points may be specified relatively in the stylesheet, this function returns the absolute [model positions](#notation/position) of the segment points. The points are specified in the order of source-to-target direction.
