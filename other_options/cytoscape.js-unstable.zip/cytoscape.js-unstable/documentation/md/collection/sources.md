## Examples

```js
var edges = cy.$('#je, #kg');

edges.sources();
```