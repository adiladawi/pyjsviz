## Examples

```js
cy.$('#j').grabify();
```