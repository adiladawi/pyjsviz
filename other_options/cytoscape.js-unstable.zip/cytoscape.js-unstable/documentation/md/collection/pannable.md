## Description

A pannable element allows passthrough panning:  The user can pan the graph when dragging on the element.  Thus, a pannable element is necessarily ungrabbable.

By default, an edge is pannable and a node is not pannable.