## Examples

Toggle:
```js
cy.$('#j, #e').toggleClass('foo');
```

Toggle on:
```js
cy.$('#j, #e').toggleClass('foo', true);
```

Toggle off:
```js
cy.$('#j, #e').toggleClass('foo', false);
```