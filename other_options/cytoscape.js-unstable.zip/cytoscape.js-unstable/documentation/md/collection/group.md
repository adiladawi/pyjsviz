## Details

The group strings are `'nodes'` for nodes and `'edges'` for edges.  In general, you should be using `ele.isEdge()` and `ele.isNode()` instead of `ele.group()`.