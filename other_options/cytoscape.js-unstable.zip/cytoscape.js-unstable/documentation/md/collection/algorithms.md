<!-- maintain the old algorithms link -->
<div id="collection/algorithms"></div>
