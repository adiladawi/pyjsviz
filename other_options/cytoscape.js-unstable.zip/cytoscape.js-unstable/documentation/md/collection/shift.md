## Examples

```js
cy.$('#j').shift({ x: 10, y: 20 });
```