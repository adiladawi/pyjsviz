## Examples

Get predecessors of `j`:
```js
cy.$('#j').predecessors();
```