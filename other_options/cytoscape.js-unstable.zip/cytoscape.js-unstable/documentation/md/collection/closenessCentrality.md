## Details

This function directly returns the numerical closeness centrality value for the specified root node.

## Examples

```js
console.log( 'cc of j: ' + cy.$().cc({ root: '#j' }) );
```