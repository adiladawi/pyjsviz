## Examples

```js
cy.$('#j').unpanify();
```