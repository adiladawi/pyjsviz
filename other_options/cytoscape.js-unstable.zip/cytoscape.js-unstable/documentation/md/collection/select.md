## Examples

```js
cy.$('#j').select();
```