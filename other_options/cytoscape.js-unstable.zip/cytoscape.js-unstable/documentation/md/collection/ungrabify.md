## Examples

```js
cy.$('#j').ungrabify();
```