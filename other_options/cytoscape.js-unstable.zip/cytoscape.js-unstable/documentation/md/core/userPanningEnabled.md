## Examples

Enable:
```js
cy.userPanningEnabled( true );
```

Disable:
```js
cy.userPanningEnabled( false );
```