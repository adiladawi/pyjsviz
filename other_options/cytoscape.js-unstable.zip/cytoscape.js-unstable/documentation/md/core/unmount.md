## Details

This function sets the instance to be headless after unmounting from the current container.