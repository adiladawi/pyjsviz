## Examples

Enable:
```js
cy.autounselectify( true );
```

Disable:
```js
cy.autounselectify( false );
```