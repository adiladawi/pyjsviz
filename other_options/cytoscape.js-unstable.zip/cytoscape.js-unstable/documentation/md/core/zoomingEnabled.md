## Examples

Enable:
```js
cy.zoomingEnabled( true );
```

Disable:
```js
cy.zoomingEnabled( false );
```