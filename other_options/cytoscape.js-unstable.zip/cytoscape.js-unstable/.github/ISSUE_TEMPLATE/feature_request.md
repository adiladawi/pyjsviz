---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Description of new feature**

_What should the new feature do?  For visual features, include an image/mockup of the expected output._



**Motivation for new feature**

_Describe your use case for this new feature._
