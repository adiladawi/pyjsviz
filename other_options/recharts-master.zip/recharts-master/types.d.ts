declare module 'recharts-scale';
declare module 'react-smooth';
declare module 'reduce-css-calc';
