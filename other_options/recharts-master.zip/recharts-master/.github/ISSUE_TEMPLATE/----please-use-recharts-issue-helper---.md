---
name: '⚠️ Please use https://recharts.github.io/recharts-issue-helper ⚠️'
about: The issue which is not created via https://recharts.github.io/recharts-issue-helper will be closed immediately.
labels:
---

The issue which is not created via https://recharts.github.io/recharts-issue-helper will be closed immediately.

---

注意：不是用 https://recharts.github.io/recharts-issue-helper 创建的 issue 会被立即关闭。