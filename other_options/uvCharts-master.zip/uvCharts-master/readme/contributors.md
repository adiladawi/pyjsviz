### Contributors

- **Kiran Danduprolu** (@hashd)
- **Sanjay Pavan C** (@sanjaypavan)
- **Madhur Shrimal** (@shrimalmadhur)
- **Priyanka Dudani** (@priyankadudani)
- **Krishnam Raj Goud** (@ksnov)
- **Pankaj Kumar** (@pankajkumar005)

### Designers

- **Paridhi Verma** (@paridhiv)
- **Noorul Ameen**
- **Kiran Kumar G**
