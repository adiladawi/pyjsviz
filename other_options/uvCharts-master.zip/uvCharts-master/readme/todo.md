##TODO
----------
- New Graphs need to be supported
- jQuery Plugin UI needs to be developed
- legend related effects need to plugged in - WIP
