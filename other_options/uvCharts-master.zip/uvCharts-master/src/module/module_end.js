  if (!noGlobal) {
    window.uv = {
      chart: uv.chart
    };
  }

  return {
    chart: uv.chart
  };
}));
