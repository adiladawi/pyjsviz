"use strict";
describe('Data update', function () {
  beforeEach(function () {
    browser.get('data_update.html');
  });
});
