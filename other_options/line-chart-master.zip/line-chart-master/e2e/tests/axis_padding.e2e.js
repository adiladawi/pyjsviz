'use strict';
describe('Axis padding', function () {
  beforeEach(function () {
    browser.get('axis_padding.html');
  });
});
