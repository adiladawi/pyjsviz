export interface IDomains {
  x?: (number|Date)[];
  x2?: (number|Date)[];
  y?: number[];
  y2?: number[];
}
