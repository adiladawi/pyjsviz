export interface IPoint {
  x: number;
  y0: number;
  y1: number;
}
