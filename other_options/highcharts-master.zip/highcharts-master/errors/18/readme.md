# The requested axis does not exist

This error happens when setting a series' `xAxis` or `yAxis` property to point
to an axis that does not exist.
