Areaspline chart
================

The areaspline chart is the same as area, only the line is a spline instead of straight lines.

<iframe style="width: 100%; height: 470px; border: none;" src="https://www.highcharts.com/samples/embed/highcharts/demo/areaspline" allow="fullscreen"></iframe>

For an overview of the areaspline chart options see the [API reference](https://api.highcharts.com/highcharts/plotOptions.areaspline).