var data = {
  labels: ['A', 'B', 'C'],
  series: [[10, 8, 14]]
};
