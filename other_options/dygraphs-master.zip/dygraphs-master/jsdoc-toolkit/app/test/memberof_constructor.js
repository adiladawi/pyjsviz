/** @constructor */
function Circle(){}

/**
	@constructor
	@memberOf Circle#
 */
Circle.prototype.Tangent = function(){};

// renaming Circle#Tangent to Circle#Circle#Tangent

/**
	@memberOf Circle#Tangent#
 */
Circle.prototype.Tangent.prototype.getDiameter = function(){};


